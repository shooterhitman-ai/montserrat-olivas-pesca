package com.montserratolivas.pesca;
import android.app.*;import android.content.*;import android.os.Build;
public class FishingAlarmReceiver extends android.content.BroadcastReceiver {
 public static final String CHANNEL="pesca_horas";
 public static void channel(Context c){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL,"Mejores horas de pesca",NotificationManager.IMPORTANCE_DEFAULT);((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);}}
 @Override public void onReceive(Context c,Intent intent){channel(c);String hour=intent.getStringExtra("hour");if(hour==null)hour="próximamente";Intent launch=new Intent(c,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(c,0,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);b.setSmallIcon(android.R.drawable.ic_menu_my_calendar).setContentTitle("🎣 Buena hora para pescar en 60 minutos").setContentText("Ventana estimada: "+hour+". Consulta el clima antes de salir.").setAutoCancel(true).setContentIntent(pi);try{((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(intent.getIntExtra("id",100),b.build());}catch(SecurityException ignored){}
 }
}
