# Calendario Pesca Lunisolar Darksec 1.10.0

Proyecto Android Studio listo para compilar con GitHub Actions. La app conserva GPS, calendario y fases lunares, widgets y notificaciones de pesca/clima.

## Novedades 1.10.0

- Buscar lugares por nombre en el mapa con resultados de Open-Meteo Geocoding.
- Iniciar una búsqueda por voz en Android con permiso de micrófono solicitado al tocar el botón; el buscador manual siempre está disponible.
- Guardar, volver a usar, renombrar y eliminar hasta 100 lugares favoritos. Android los conserva entre instalaciones de la app; el mismo lugar alimenta el mapa, el pronóstico, el GPS del widget y los avisos.
- Mostrar lluvia por hora (probabilidad e intensidad), sensación térmica, humedad, ráfagas y hora de referencia junto con el pronóstico diario.
- Temperatura, viento, lluvia y horarios respetan las unidades y el formato 12/24 h configurados.

## Compilar desde GitHub en Android

1. Descarga el ZIP del proyecto y extráelo con **Archivos** en el teléfono.
2. En GitHub abre el repositorio `shooterhitman-ai/montserrat-olivas-pesca` y añade los archivos extraídos a la rama `main`, conservando las carpetas. También puedes abrir el proyecto extraído en Android Studio si tienes un equipo de escritorio.
3. Asegúrate de que `.github/workflows/android.yml` quede en la raíz del repositorio. Si GitHub no permite subir directorios desde el teléfono, crea ese archivo desde **Add file → Create new file** y copia el contenido del workflow incluido en este proyecto.
4. Abre **Actions**, espera a que termine **Construir APK Android** y descarga `Lunisolar-Darksec-APK-v1.10.0` en **Artifacts**.
5. Abre el APK descargado y permite a Android instalar aplicaciones desde el navegador/Archivos si lo solicita.

La búsqueda por voz solo pide permiso de micrófono cuando se toca **Voz**. Si se deniega o no hay un servicio de reconocimiento disponible, escribe el lugar en el campo de búsqueda.

## Compilación local

Se requiere JDK 17 y Gradle 8.9. Desde la raíz del proyecto ejecuta `gradle assembleDebug`; el APK queda en `app/build/outputs/apk/debug/app-debug.apk`.
