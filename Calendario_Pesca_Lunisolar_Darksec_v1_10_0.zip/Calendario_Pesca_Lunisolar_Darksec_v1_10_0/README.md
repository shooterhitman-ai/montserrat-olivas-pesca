# Calendario Pesca Lunisolar Darksec 1.10.0

Proyecto Android Studio listo para compilar con GitHub Actions. La app conserva GPS, calendario y fases lunares, widgets y notificaciones de pesca/clima.

## Novedades 1.10.0

- Buscar lugares por nombre en el mapa con resultados de Open-Meteo Geocoding.
- Iniciar una búsqueda por voz en Android con permiso de micrófono solicitado al tocar el botón; el buscador manual siempre está disponible.
- Guardar, volver a usar, renombrar y eliminar hasta 100 lugares favoritos. Android los conserva entre instalaciones de la app; el mismo lugar alimenta el mapa, el pronóstico, el GPS del widget y los avisos.
- Mostrar lluvia por hora (probabilidad e intensidad), sensación térmica, humedad, ráfagas y hora de referencia junto con el pronóstico diario.
- Temperatura, viento, lluvia y horarios respetan las unidades y el formato 12/24 h configurados.

## Compilar desde GitHub en Android

1. Descarga el ZIP del proyecto y `android.yml` en el teléfono. No extraigas el ZIP para subirlo a GitHub.
2. En GitHub abre `shooterhitman-ai/montserrat-olivas-pesca` y reemplaza el contenido del workflow existente en `.github/workflows/android.yml` por el archivo `android.yml`. Confirma el cambio en `main`.
3. En el repositorio, abre el workflow existente `.github/workflows/android.yml`, pulsa Editar y reemplaza todo su contenido por `android.yml` incluido. Confirma el cambio en `main`.
3. Sube el ZIP `Calendario_Pesca_Lunisolar_Darksec_v1_10_0.zip` a la raíz del repositorio y confirma el cambio en `main`. Luego abre **Actions**, espera a que termine **Compilar APK Android - Lunisolar Darksec** y descarga `Lunisolar-Darksec-APK-v1.10.0` en **Artifacts**.
4. Extrae el artifact y abre `app-debug.apk` y permite a Android instalar aplicaciones desde el navegador/Archivos si lo solicita.

La búsqueda por voz solo pide permiso de micrófono cuando se toca **Voz**. Si se deniega o no hay un servicio de reconocimiento disponible, escribe el lugar en el campo de búsqueda.

## Compilación local

Se requiere JDK 17 y Gradle 8.9. Desde la raíz del proyecto ejecuta `gradle assembleDebug`; el APK queda en `app/build/outputs/apk/debug/app-debug.apk`.
