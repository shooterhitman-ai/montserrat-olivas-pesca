(() => {
  const plugin = {
    id: 'darksecCurrentTimeMarker',
    afterDatasetsDraw(chart, _args, options) {
      const times = options?.timestamps;
      if (!Array.isArray(times) || times.length < 2) return;
      const now = Date.now();
      let rightIndex = times.findIndex(value => value >= now);
      if (rightIndex < 0) return;
      const leftIndex = Math.max(0, rightIndex - 1);
      rightIndex = Math.min(times.length - 1, leftIndex + 1);
      if (rightIndex === leftIndex) return;
      const leftTime = times[leftIndex], rightTime = times[rightIndex];
      if (!Number.isFinite(leftTime) || !Number.isFinite(rightTime) || rightTime <= leftTime) return;
      const fraction = Math.max(0, Math.min(1, (now - leftTime) / (rightTime - leftTime)));
      const xScale = chart.scales.x;
      const chartArea = chart.chartArea;
      if (!xScale || !chartArea) return;
      const x0 = xScale.getPixelForValue(leftIndex);
      const x1 = xScale.getPixelForValue(rightIndex);
      const x = x0 + (x1 - x0) * fraction;
      if (!Number.isFinite(x)) return;

      const ctx = chart.ctx;
      ctx.save();
      ctx.beginPath();
      ctx.setLineDash([5, 4]);
      ctx.strokeStyle = '#ff7895';
      ctx.lineWidth = 2;
      ctx.moveTo(x, chartArea.top);
      ctx.lineTo(x, chartArea.bottom);
      ctx.stroke();
      ctx.setLineDash([]);

      let timeLabel = '';
      try {
        timeLabel = new Intl.DateTimeFormat('es-MX', {
          timeZone: options.timeZone || undefined,
          hour: '2-digit',
          minute: '2-digit',
          hourCycle: options.timeFormat === '12h' ? 'h12' : 'h23'
        }).format(new Date(now));
      } catch (_) { }
      const label = timeLabel ? `AHORA · ${timeLabel}` : 'AHORA';
      ctx.font = '700 10px system-ui, sans-serif';
      const width = ctx.measureText(label).width + 14;
      const height = 20;
      const left = Math.max(chartArea.left, Math.min(x - width / 2, chartArea.right - width));
      const top = chartArea.top + 4;
      ctx.fillStyle = '#c83d61';
      ctx.fillRect(left, top, width, height);
      ctx.fillStyle = '#ffffff';
      ctx.textBaseline = 'middle';
      ctx.fillText(label, left + 7, top + height / 2);
      ctx.restore();
    }
  };
  if (window.Chart && !window.Chart.registry.plugins.get(plugin.id)) window.Chart.register(plugin);
  window.DarksecCurrentTimeMarker = plugin;
})();
