package com.montserratolivas.pesca;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.util.TypedValue;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Widget de resumen: no realiza consultas propias; solo muestra el último pronóstico guardado. */
public class MoonWidget extends AppWidgetProvider {
    private static final String ACTION_REFRESH = "com.montserratolivas.pesca.WIDGET_REFRESH";
    @Override public void onReceive(Context c, Intent intent) {
        super.onReceive(c, intent);
        if (ACTION_REFRESH.equals(intent.getAction())) {
            WeatherRefreshWorker.refreshNow(c, true);
            refresh(c);
        }
    }
    public static void refresh(Context c) {
        AppWidgetManager manager = AppWidgetManager.getInstance(c);
        int[] ids = manager.getAppWidgetIds(new ComponentName(c, MoonWidget.class));
        if (ids != null && ids.length > 0) new MoonWidget().onUpdate(c, manager, ids);
        PotentialWidget.refresh(c);
    }
    private static String formatHour(String hhmm, boolean use12h) {
        if (hhmm == null || hhmm.length() < 5) return "—";
        try {
            int h = Integer.parseInt(hhmm.substring(0, 2));
            int m = Integer.parseInt(hhmm.substring(3, 5));
            if (use12h) {
                String suffix = h >= 12 ? "PM" : "AM";
                int hour = ((h + 11) % 12) + 1;
                return String.format(Locale.getDefault(), "%d:%02d %s", hour, m, suffix);
            }
            return String.format(Locale.getDefault(), "%02d:%02d", h, m);
        } catch (Exception ignored) {
            return hhmm;
        }
    }
    private static String niceTime(long epoch, boolean use12h) {
        return new SimpleDateFormat(use12h ? "dd/MM hh:mm a" : "dd/MM HH:mm", Locale.getDefault()).format(new Date(epoch));
    }
    private static String eventDate(JSONObject event, long now, boolean use12h) {
        long stamp = event.optLong("epochMs", 0);
        if (stamp <= now) return "";
        String forecastDay = event.optString("day", "");
        String displayDay = forecastDay.length() == 10
            ? forecastDay.substring(8, 10) + "/" + forecastDay.substring(5, 7)
            : "Próx.";
        String hour = formatHour(event.optString("hour", "—"), use12h);
        return displayDay + "  " + hour + "     " + event.optInt("score") + "/100";
    }
    private static String skyIcon(int code, String risk) {
        if ("bad".equals(risk)) return "⚠️";
        if (code >= 95) return "⛈️";
        if (code >= 80) return "🌦️";
        if (code >= 51) return "🌧️";
        if (code >= 45) return "🌫️";
        if (code >= 4 && code < 40) return "☁️";
        if (code == 3) return "☁️";
        if (code >= 1 && code <= 2) return "⛅";
        if (code == 0) return "☀️";
        return "🌤️";
    }
    private static void adjust(RemoteViews v, int id, float base, float factor) {
        v.setTextViewTextSize(id, TypedValue.COMPLEX_UNIT_SP, base*factor);
    }
    @Override public void onUpdate(Context c, AppWidgetManager manager, int[] ids) {
        SharedPreferences p = AppSettings.prefs(c);
        double days = (System.currentTimeMillis()/86400000.0-10957.5-5.2597) % 29.530588853;
        if (days < 0) days += 29.530588853;
        String[] names = {"Nueva", "Creciente", "Cuarto creciente", "Gibosa creciente", "Llena", "Gibosa menguante", "Cuarto menguante", "Menguante"};
        String[] symbols = {"🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘"};
        int phase = ((int) Math.round(days / 29.530588853 * 8)) % 8;
        boolean use12h = "12h".equals(p.getString("time_format", "24h"));
        long updated = p.getLong("widget_weather_updated", 0L);
        long age = System.currentTimeMillis() - updated;
        boolean hasLocation = p.getBoolean("location_selected", false);
        boolean fresh = updated > 0 && age >= 0 && age < 12L * 3600000L;
        String updatedLabel = updated > 0 ? "Act. " + niceTime(updated, use12h) : "Sin actualizar";
        String label = p.getString("widget_status", "Sin pronóstico");
        String risk = p.getString("widget_risk_level", "unknown");
        if (!hasLocation) label = "Configura zona";
        else if (!fresh) label = updated > 0 ? "Datos antiguos" : "Sin pronóstico";
        String[] best = {hasLocation ? "— Pulsa ↻ para consultar" : "— Elige GPS en Ajustes", "", ""};
        try {
            JSONArray events = new JSONArray(p.getString("widget_top_events", "[]"));
            int shown = 0;
            long now = System.currentTimeMillis();
            int minScore = p.getInt("min_score", 65);
            for(int i=0;i<events.length() && shown<3;i++) {
                JSONObject e = events.optJSONObject(i);
                if(e == null || e.optInt("score",-1) < minScore || e.optLong("epochMs",0) <= now) continue;
                String formatted = eventDate(e,now,use12h);
                if (formatted.isEmpty()) continue;
                if(shown == 0) best[0] = formatted;
                else best[shown] = formatted;
                shown++;
            }
        } catch (Exception ignored) { }
        boolean showHours = p.getBoolean("widget_hours", true);
        boolean showWeather = p.getBoolean("widget_weather", true);
        boolean compact = p.getBoolean("widget_compact", false);
        float fontFactor = Math.max(0.85f, Math.min(1.4f, p.getInt("widget_font_scale", 110) / 100f));
        String theme = p.getString("widget_theme", "ocean");
        int background = "forest".equals(theme) ? R.drawable.widget_background_forest
            : "night".equals(theme) ? R.drawable.widget_background_night : R.drawable.widget_background;
        int statusColor = !fresh ? Color.rgb(186, 205, 218)
            : "bad".equals(risk) ? Color.rgb(255, 163, 159)
            : "caution".equals(risk) ? Color.rgb(255, 215, 142) : Color.rgb(122, 245, 206);
        for (int id : ids) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.moon_widget);
            v.setInt(R.id.widget_root, "setBackgroundResource", background);
            v.setTextViewText(R.id.widget_moon_icon, symbols[phase]);
            v.setTextViewText(R.id.widget_weather_icon, skyIcon(p.getInt("widget_weather_code",-1), fresh ? risk : "unknown"));
            for (int[] entry : new int[][] {
                {R.id.widget_title, 9},{R.id.widget_updated, 9},{R.id.widget_moon, 16},
                {R.id.widget_subtitle, 9},{R.id.widget_status, 9},{R.id.widget_zone, 11},
                {R.id.widget_risk_detail, 10},{R.id.widget_data_hour, 9},
                {R.id.widget_temp, 15},{R.id.widget_rain, 15},{R.id.widget_wind, 12},
                {R.id.widget_hour1, 11},{R.id.widget_hour2, 11},{R.id.widget_hour3, 11},
                {R.id.widget_footnote, 8}
            }) adjust(v, entry[0], entry[1], fontFactor);
            adjust(v, R.id.widget_moon_icon, 34, Math.min(1.2f, fontFactor));
            adjust(v, R.id.widget_weather_icon, 21, Math.min(1.2f, fontFactor));
            v.setTextViewText(R.id.widget_moon, names[phase]);
            v.setTextViewText(R.id.widget_subtitle, "Fase aproximada · clima Open-Meteo");
            v.setTextViewText(R.id.widget_zone, hasLocation
                ? "📍 " + p.getString("widget_zone", String.format(java.util.Locale.US, "%.3f, %.3f",
                    Double.longBitsToDouble(p.getLong("lat_bits", 0L)),
                    Double.longBitsToDouble(p.getLong("lon_bits", 0L))))
                : "📍 Elige GPS o punto del mapa en Ajustes");
            v.setTextViewText(R.id.widget_updated, updatedLabel);
            String forecastTime = p.getString("widget_forecast_time", "");
            String hourLabel = forecastTime.length() >= 16
                ? forecastTime.substring(8, 10) + "/" + forecastTime.substring(5, 7) + " · " + formatHour(forecastTime.substring(11, 16), use12h)
                : "próxima hora";
            v.setTextViewText(R.id.widget_data_hour, fresh
                ? "Pronóstico de " + hourLabel + " · Open-Meteo"
                : "Pronóstico no actualizado · abre la app o pulsa ↻");
            v.setTextViewText(R.id.widget_status, label);
            v.setTextColor(R.id.widget_status, statusColor);
            String riskText = p.getString("widget_risk_detail", "");
            String riskTime = p.getString("widget_risk_time", "");
            if (!hasLocation) riskText = "📍 Activa GPS o selecciona tu zona";
            else if (!fresh) riskText = "Pronóstico desactualizado; pulsa ↻";
            else if (!riskText.isEmpty() && riskTime.length() >= 5) riskText += " · " + formatHour(riskTime, use12h);
            else if (riskText.isEmpty()) riskText = "Sin riesgos relevantes en 12 h";
            v.setTextViewText(R.id.widget_risk_detail, riskText);
            v.setTextColor(R.id.widget_risk_detail, statusColor);
            v.setViewVisibility(R.id.widget_risk_detail, showWeather ? View.VISIBLE : View.GONE);
            v.setTextViewText(R.id.widget_temp, p.getString("widget_temp", "— °C"));
            v.setTextViewText(R.id.widget_rain, p.getString("widget_rain", "— %"));
            v.setTextViewText(R.id.widget_wind, p.getString("widget_wind", "— km/h"));
            v.setViewVisibility(R.id.widget_weather_section, showWeather ? View.VISIBLE : View.GONE);
            v.setViewVisibility(R.id.widget_hours_section, showHours ? View.VISIBLE : View.GONE);
            v.setTextViewText(R.id.widget_hour1, best[0]);
            v.setTextViewText(R.id.widget_hour2, best[1]);
            v.setTextViewText(R.id.widget_hour3, best[2]);
            v.setViewVisibility(R.id.widget_hour2, !best[1].isEmpty() && showHours && !compact ? View.VISIBLE : View.GONE);
            v.setViewVisibility(R.id.widget_hour3, !best[2].isEmpty() && showHours && !compact ? View.VISIBLE : View.GONE);
            v.setTextViewText(R.id.widget_footnote, "Índice de pesca orientativo, no probabilidad de captura · Open-Meteo");
            v.setViewVisibility(R.id.widget_footnote, compact ? View.GONE : View.VISIBLE);
            v.setViewVisibility(R.id.widget_subtitle, compact ? View.GONE : View.VISIBLE);
            PendingIntent action = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            v.setOnClickPendingIntent(R.id.widget_root, action);
            Intent refreshAction = new Intent(c, MoonWidget.class).setAction(ACTION_REFRESH);
            PendingIntent refreshIntent = PendingIntent.getBroadcast(c, 33421, refreshAction,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            v.setOnClickPendingIntent(R.id.widget_reload, refreshIntent);
            manager.updateAppWidget(id, v);
        }
        if (hasLocation) WeatherRefreshWorker.refreshNow(c, false);
    }
}
