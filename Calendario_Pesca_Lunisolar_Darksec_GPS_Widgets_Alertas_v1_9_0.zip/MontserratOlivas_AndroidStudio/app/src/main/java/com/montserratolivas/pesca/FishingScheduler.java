package com.montserratolivas.pesca;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Programa notificaciones para el pronóstico vigente. Un máximo de 48 alarmas evita saturar Android. */
public final class FishingScheduler {
    public static final int MAX_PENDING = 48;
    private FishingScheduler() { }
    static void cancel(Context c) {
        AlarmManager manager = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        for (int i = 0; i < MAX_PENDING; i++) {
            PendingIntent pi = PendingIntent.getBroadcast(c, 700 + i,
                new Intent(c, FishingAlarmReceiver.class), PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) { manager.cancel(pi); pi.cancel(); }
        }
    }
    public static void apply(Context c, String json, boolean save) {
        try {
            JSONObject schedule = new JSONObject(json);
            JSONArray events = schedule.getJSONArray("events");
            SharedPreferences p = AppSettings.prefs(c);
            if (save) p.edit().putString("schedule", json).apply();
            updateWidgetHours(c, events);
            cancel(c);
            if (!p.getBoolean("alerts_enabled", true)) { MoonWidget.refresh(c); return; }
            AlarmManager manager = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (manager == null) return;
            int leadHours = p.getInt("lead_hours", 1);
            int maxPerDay = p.getInt("max_alerts", 0);
            int minScore = p.getInt("min_score", 65);
            String currentDay = "";
            int dayCount = 0;
            int scheduled = 0;
            // La web entrega los eventos por hora, ordenados cronológicamente.
            for (int i = 0; i < events.length() && scheduled < MAX_PENDING; i++) {
                JSONObject event = events.optJSONObject(i);
                if (event == null) continue;
                int score = event.optInt("score", -1);
                if (score < minScore) continue;
                String day = event.optString("day", "");
                if (!day.equals(currentDay)) { currentDay = day; dayCount = 0; }
                if (maxPerDay > 0 && dayCount >= maxPerDay) continue;
                long start = event.optLong("epochMs", 0L);
                long when = start - leadHours * 3600000L;
                if (start <= System.currentTimeMillis() || when <= System.currentTimeMillis()) continue;
                dayCount++;
                String hour = event.optString("hour", "");
                Intent intent = new Intent(c, FishingAlarmReceiver.class)
                    .putExtra("hour", hour).putExtra("day", day).putExtra("leadHours", leadHours)
                    .putExtra("score", score).putExtra("id", 700 + scheduled);
                PendingIntent pi = PendingIntent.getBroadcast(c, 700 + scheduled, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
                scheduled++;
            }
            p.edit().putInt("scheduled_count", scheduled).apply();
            MoonWidget.refresh(c);
        } catch (Exception ignored) { }
    }
    private static void updateWidgetHours(Context c, JSONArray events) {
        SharedPreferences prefs = AppSettings.prefs(c);
        int minScore = prefs.getInt("min_score", 65);
        long now = System.currentTimeMillis();
        JSONArray next = new JSONArray();
        for (int i = 0; i < events.length() && next.length() < 64; i++) {
            JSONObject e = events.optJSONObject(i);
            if (e == null || e.optInt("score", -1) < minScore || e.optLong("epochMs", 0) <= now) continue;
            next.put(e);
        }
        JSONArray all = new JSONArray();
        for (int i=0; i<events.length() && all.length()<128; i++) {
            JSONObject e=events.optJSONObject(i);
            if (e != null && e.optLong("epochMs",0)>now && e.optInt("score",-1)>=0) all.put(e);
        }
        prefs.edit().putString("widget_top_events", next.toString())
            .putString("widget_all_events", all.toString()).apply();
    }
    public static void restore(Context c) {
        String saved = AppSettings.prefs(c).getString("schedule", null);
        if (saved != null) apply(c, saved, false);
        else { cancel(c); MoonWidget.refresh(c); }
    }
}
