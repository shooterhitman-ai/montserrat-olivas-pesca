package com.montserratolivas.pesca;

import android.Manifest;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int LOCATION_REQUEST = 101;
    private static final int NOTIFICATION_REQUEST = 102;
    private static final int MANUAL_GPS_REQUEST = 103;
    private boolean nativeGpsManual = true;
    private LocationManager nativeLocationManager;
    private LocationListener nativeGpsListener;
    private final Handler gpsHandler = new Handler(Looper.getMainLooper());
    private Runnable nativeGpsTimeout;
    private boolean pageReady = false;
    private volatile boolean settingsOpen = false;
    private GeolocationPermissions.Callback pendingCallback;
    private String pendingOrigin;

    public class NativeBridge {
        @JavascriptInterface public void settingsVisibility(boolean visible) { settingsOpen = visible; }
        @JavascriptInterface public String getSettings() { return AppSettings.read(MainActivity.this).toString(); }
        @JavascriptInterface public void saveSettings(String json) {
            runOnUiThread(() -> AppSettings.save(MainActivity.this, json));
        }
        @JavascriptInterface public void updateFishingTimes(String json) {
            runOnUiThread(() -> FishingScheduler.apply(MainActivity.this, json, true));
        }
        /** Actualiza el resumen del widget con el último pronóstico de la ubicación elegida. */
        @JavascriptInterface public void updateWidgetWeather(String json) {
            runOnUiThread(() -> WeatherWidgetStore.save(MainActivity.this, json));
        }
        /** Solo se activa después de que el usuario selecciona GPS o un punto del mapa. */
        @JavascriptInterface public void setForecastLocation(double lat, double lon) {
            if (Double.isNaN(lat) || Double.isNaN(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) return;
            runOnUiThread(() -> {
                boolean changed = !AppSettings.prefs(MainActivity.this).getBoolean("location_selected", false)
                    || AppSettings.prefs(MainActivity.this).getLong("lat_bits", 0L) != Double.doubleToLongBits(lat)
                    || AppSettings.prefs(MainActivity.this).getLong("lon_bits", 0L) != Double.doubleToLongBits(lon);
                AppSettings.prefs(MainActivity.this).edit().putBoolean("location_selected", true)
                    .putLong("lat_bits", Double.doubleToLongBits(lat))
                    .putLong("lon_bits", Double.doubleToLongBits(lon)).apply();
                if (changed) {
                    AppSettings.prefs(MainActivity.this).edit()
                        .remove("widget_weather_updated").remove("widget_top_events").remove("widget_all_events")
                        .remove("widget_last_error").remove("widget_last_refresh_request")
                        .remove("widget_temp").remove("widget_rain").remove("widget_wind").remove("widget_forecast_time")
                        .remove("widget_status").remove("widget_zone").remove("widget_risk_detail").remove("widget_risk_time")
                        .remove("schedule").putInt("scheduled_count", 0).apply();
                    FishingScheduler.cancel(MainActivity.this);
                }
                WeatherRefreshWorker.schedule(MainActivity.this);
                WeatherRefreshWorker.refreshNow(MainActivity.this, changed);
                MoonWidget.refresh(MainActivity.this);
            });
        }
        @JavascriptInterface public String getForecastLocation() {
            android.content.SharedPreferences prefs = AppSettings.prefs(MainActivity.this);
            if (!prefs.getBoolean("location_selected", false)) return "";
            double a = Double.longBitsToDouble(prefs.getLong("lat_bits", 0L));
            double b = Double.longBitsToDouble(prefs.getLong("lon_bits", 0L));
            if (!Double.isFinite(a) || !Double.isFinite(b) || a < -90 || a > 90 || b < -180 || b > 180) return "";
            return "{\"lat\":" + a + ",\"lon\":" + b + "}";
        }
        @JavascriptInterface public boolean notificationPermissionGranted() {
            return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }
        @JavascriptInterface public void requestNotificationPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
                }
            });
        }
        @JavascriptInterface public void openNotificationSettings() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                    i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                    startActivity(i);
                } catch (Exception e) {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                }
            });
        }
        @JavascriptInterface public boolean canPinWidget() {
            return Build.VERSION.SDK_INT >= 26 && AppWidgetManager.getInstance(MainActivity.this).isRequestPinAppWidgetSupported();
        }
        @JavascriptInterface public void requestCurrentGps(boolean manual) {
            runOnUiThread(() -> requestNativeGps(manual));
        }
        @JavascriptInterface public void pinPotentialWidget() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 26) {
                    AppWidgetManager manager = AppWidgetManager.getInstance(MainActivity.this);
                    if (manager.isRequestPinAppWidgetSupported()) {
                        manager.requestPinAppWidget(new ComponentName(MainActivity.this, PotentialWidget.class), null, null);
                    }
                }
            });
        }
        @JavascriptInterface public void pinMoonWidget() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 26) {
                    AppWidgetManager manager = AppWidgetManager.getInstance(MainActivity.this);
                    if (manager.isRequestPinAppWidgetSupported()) {
                        manager.requestPinAppWidget(new ComponentName(MainActivity.this, MoonWidget.class), null, null);
                    }
                }
            });
        }
        @JavascriptInterface public int widgetCount() {
            int[] ids = AppWidgetManager.getInstance(MainActivity.this)
                .getAppWidgetIds(new ComponentName(MainActivity.this, MoonWidget.class));
            int[] mini = AppWidgetManager.getInstance(MainActivity.this)
                .getAppWidgetIds(new ComponentName(MainActivity.this, PotentialWidget.class));
            return (ids == null ? 0 : ids.length) + (mini == null ? 0 : mini.length);
        }
        @JavascriptInterface public String getWidgetState() {
            android.content.SharedPreferences p = AppSettings.prefs(MainActivity.this);
            try {return new org.json.JSONObject()
                .put("hasLocation", p.getBoolean("location_selected", false))
                .put("updatedAt", p.getLong("widget_weather_updated", 0))
                .put("lastError", p.getString("widget_last_error", ""))
                .put("scheduledCount", p.getInt("scheduled_count", 0)).toString();
            } catch(Exception ignored) {return "{}";}
        }
        @JavascriptInterface public void requestWeatherRefresh() {
            runOnUiThread(() -> {
                WeatherRefreshWorker.refreshNow(MainActivity.this, true);
                MoonWidget.refresh(MainActivity.this);
            });
        }
        @JavascriptInterface public void refreshWidget() {
            runOnUiThread(() -> MoonWidget.refresh(MainActivity.this));
        }
    }

    private void deliverJs(String javascript) {
        if (webView != null) webView.evaluateJavascript(javascript, null);
    }
    private void cancelGpsUpdates() {
        if (nativeGpsTimeout != null) gpsHandler.removeCallbacks(nativeGpsTimeout);
        nativeGpsTimeout = null;
        if (nativeGpsListener != null && nativeLocationManager != null) {
            try { nativeLocationManager.removeUpdates(nativeGpsListener); } catch (Exception ignored) { }
        }
        nativeGpsListener = null;
    }
    private void deliverGpsError(String message, boolean manual) {
        cancelGpsUpdates();
        deliverJs("window.darksecNativeGpsError && window.darksecNativeGpsError(" + JSONObject.quote(message)
            + "," + manual + ")");
    }
    private void deliverGpsLocation(Location location, boolean manual) {
        if (location == null || !Double.isFinite(location.getLatitude()) || !Double.isFinite(location.getLongitude())) {
            deliverGpsError("Ubicación no válida", manual); return;
        }
        cancelGpsUpdates();
        deliverJs("window.darksecNativeGpsOk && window.darksecNativeGpsOk(" + location.getLatitude() + ","
            + location.getLongitude() + "," + (location.hasAccuracy() ? location.getAccuracy() : 999)
            + "," + manual + ")");
    }
    private void requestNativeGps(boolean manual) {
        nativeGpsManual = manual;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION}, MANUAL_GPS_REQUEST);
            return;
        }
        cancelGpsUpdates();
        try {
            nativeLocationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (nativeLocationManager == null) { deliverGpsError("Servicio GPS no disponible", manual); return; }
            boolean gps = nativeLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            boolean network = nativeLocationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            if (!gps && !network) { deliverGpsError("Activa la ubicación del teléfono", manual); return; }
            Location latest = null;
            for (String provider : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                if (!nativeLocationManager.isProviderEnabled(provider)) continue;
                Location candidate = nativeLocationManager.getLastKnownLocation(provider);
                if (candidate != null && System.currentTimeMillis() - candidate.getTime() < 90000L
                    && (latest == null || candidate.getAccuracy() < latest.getAccuracy())) latest = candidate;
            }
            if (latest != null && (!latest.hasAccuracy() || latest.getAccuracy() <= 250f)) {
                deliverGpsLocation(latest, manual); return;
            }
            nativeGpsListener = location -> deliverGpsLocation(location, manual);
            if (gps) nativeLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0L, 0f, nativeGpsListener, Looper.getMainLooper());
            if (network) nativeLocationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0L, 0f, nativeGpsListener, Looper.getMainLooper());
            nativeGpsTimeout = () -> deliverGpsError("Se agotó la espera de la ubicación; revisa señal y permisos", manual);
            gpsHandler.postDelayed(nativeGpsTimeout, 18000L);
        } catch (SecurityException e) { deliverGpsError("Permiso de ubicación denegado", manual); }
        catch (Exception e) { deliverGpsError("No se pudo consultar el servicio de ubicación", manual); }
    }
    private void openNotificationDestination(Intent intent) {
        if (intent == null || !intent.hasExtra("darksec_section") || !pageReady) return;
        String kind = intent.getStringExtra("darksec_section");
        String title = intent.getStringExtra("darksec_title");
        String text = intent.getStringExtra("darksec_text");
        String day = intent.getStringExtra("darksec_day");
        String hour = intent.getStringExtra("darksec_hour");
        deliverJs("window.openDarksecNotification && window.openDarksecNotification("
            + JSONObject.quote(kind == null ? "weather" : kind) + ","
            + JSONObject.quote(title == null ? "Aviso del pronóstico" : title) + ","
            + JSONObject.quote(text == null ? "" : text) + ","
            + JSONObject.quote(day == null ? "" : day) + ","
            + JSONObject.quote(hour == null ? "" : hour) + ")");
        intent.removeExtra("darksec_section");
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        openNotificationDestination(intent);
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8, 22, 33));
        getWindow().setNavigationBarColor(Color.rgb(8, 22, 33));
        FishingAlarmReceiver.channel(this);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setGeolocationEnabled(true);
        webView.addJavascriptInterface(new NativeBridge(), "PescaAndroid");
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pageReady = true;
                openNotificationDestination(getIntent());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri address = request.getUrl();
                if ("appassets.androidplatform.net".equals(address.getHost())) return false;
                // Los enlaces externos se abren fuera de la aplicación; el puente nativo queda aislado.
                try { startActivity(new Intent(Intent.ACTION_VIEW, address)); }
                catch (Exception ignored) { }
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingCallback = callback;
                    pendingOrigin = origin;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
                }
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html?v=190");
        MoonWidget.refresh(this);
        WeatherRefreshWorker.schedule(this);
        WeatherRefreshWorker.refreshNow(this, false);
    }
    @Override protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.evaluateJavascript("window.updatePermissionLabel && window.updatePermissionLabel(); window.updateWidgetStatus && window.updateWidgetStatus(); window.autoGpsOnOpen && window.autoGpsOnOpen();", null);
        }
    }
    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == LOCATION_REQUEST && pendingCallback != null) {
            boolean ok = false;
            for (int grant : results) if (grant == PackageManager.PERMISSION_GRANTED) ok = true;
            pendingCallback.invoke(pendingOrigin, ok, false);
            pendingCallback = null;
            pendingOrigin = null;
        }
        if (code == MANUAL_GPS_REQUEST) {
            boolean granted = false;
            for (int result : results) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
            if (granted) requestNativeGps(nativeGpsManual);
            else deliverGpsError("Permiso GPS denegado: habilítalo desde Ajustes de Android", nativeGpsManual);
        }
        if (code == NOTIFICATION_REQUEST && webView != null) {
            webView.evaluateJavascript("window.updatePermissionLabel && window.updatePermissionLabel()", null);
        }
    }
    @Override protected void onDestroy() {
        cancelGpsUpdates();
        super.onDestroy();
    }
    @Override public void onBackPressed() {
        if (settingsOpen && webView != null) {
            webView.evaluateJavascript("window.closeSettingsIfOpen && window.closeSettingsIfOpen()", null);
            return;
        }
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
