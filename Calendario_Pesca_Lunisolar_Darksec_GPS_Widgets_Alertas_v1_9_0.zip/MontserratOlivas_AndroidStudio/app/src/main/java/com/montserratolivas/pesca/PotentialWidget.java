package com.montserratolivas.pesca;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Índice orientativo de pesca: NO representa una probabilidad de capturar peces. */
public class PotentialWidget extends AppWidgetProvider {
    private static final String REFRESH="com.montserratolivas.pesca.POTENTIAL_REFRESH";
    public static void refresh(Context context) {
        AppWidgetManager manager=AppWidgetManager.getInstance(context);
        int[] ids=manager.getAppWidgetIds(new ComponentName(context,PotentialWidget.class));
        if(ids!=null&&ids.length>0)new PotentialWidget().onUpdate(context,manager,ids);
    }
    private static String hour(Context context, String h) {
        return FishingAlarmReceiver.displayHour(context,h);
    }
    @Override public void onReceive(Context c, Intent i) {
        super.onReceive(c,i);
        if(REFRESH.equals(i.getAction())){
            WeatherRefreshWorker.refreshNow(c,true);
            refresh(c);
        }
    }
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){
        SharedPreferences p=AppSettings.prefs(c);
        String tz=p.getString("widget_tz","");
        SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd",Locale.US);
        if(!tz.isEmpty())formatter.setTimeZone(TimeZone.getTimeZone(tz));
        String today=formatter.format(new Date());
        long now=System.currentTimeMillis();
        boolean location=p.getBoolean("location_selected",false);
        long updated=p.getLong("widget_weather_updated",0L);
        boolean fresh=updated>0 && now>=updated && now-updated<12L*3600000L;
        int best=-1;
        String time="";
        try{
            JSONArray events=new JSONArray(p.getString("widget_all_events","[]"));
            for(int i=0;i<events.length();i++){
                JSONObject e=events.optJSONObject(i);
                if(e==null||!today.equals(e.optString("day"))||e.optLong("epochMs",0)<=now)continue;
                int score=e.optInt("score",-1);
                if(score>best){best=score;time=e.optString("hour","");}
            }
        }catch(Exception ignored){}
        String risk=p.getString("widget_risk_level","unknown");
        boolean riskBad=fresh&&"bad".equals(risk);
        String grade, status, hourText,scoreText;
        int background;int numberColor;
        if(!location||!fresh){
            grade="SIN PRONÓSTICO";
            status=!location?"Selecciona ubicación en Ajustes":"Actualiza clima para ver el potencial";
            hourText="GPS / pronóstico";scoreText="—";
            background=R.drawable.potential_bg_neutral;numberColor=Color.WHITE;
        }else if(best<0){
            grade=riskBad?"CLIMA ADVERSO":"SIN HORAS FUTURAS";
            status=riskBad?p.getString("widget_risk_detail","Evita salir con inclemencias"):"Consulta la próxima jornada";
            hourText="Hoy · sin hora segura";scoreText="—";
            background=riskBad?R.drawable.potential_bg_low:R.drawable.potential_bg_neutral;numberColor=Color.WHITE;
        }else {
            scoreText=best+"%";
            hourText="Mejor: "+hour(c,time);
            status=riskBad?p.getString("widget_risk_detail","Precaución por clima"):
                "Índice estimado · no prob. de captura";
            if(riskBad){grade="PRECAUCIÓN";background=R.drawable.potential_bg_low;numberColor=Color.rgb(255,200,194);}
            else if(best>=75){grade="ALTO";background=R.drawable.potential_bg_high;numberColor=Color.rgb(181,255,227);}
            else if(best>=50){grade="MEDIO";background=R.drawable.potential_bg_medium;numberColor=Color.rgb(255,224,152);}
            else{grade="BAJO";background=R.drawable.potential_bg_low;numberColor=Color.rgb(255,196,196);}
        }
        for(int id:ids){
            RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.potential_widget);
            v.setInt(R.id.potential_root,"setBackgroundResource",background);
            v.setTextViewText(R.id.potential_value,scoreText);
            v.setTextColor(R.id.potential_value,numberColor);
            v.setTextViewText(R.id.potential_grade,grade);
            v.setTextViewText(R.id.potential_best_hour,hourText);
            v.setTextViewText(R.id.potential_status,status);
            Intent open=new Intent(c,MainActivity.class).putExtra("darksec_section","fishing")
                .putExtra("darksec_title","🎣 Potencial de pesca de hoy")
                .putExtra("darksec_text",status)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            v.setOnClickPendingIntent(R.id.potential_root,
                PendingIntent.getActivity(c,22001,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
            Intent refresh=new Intent(c,PotentialWidget.class).setAction(REFRESH);
            v.setOnClickPendingIntent(R.id.potential_refresh,
                PendingIntent.getBroadcast(c,22002,refresh,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
            m.updateAppWidget(id,v);
        }
        if(location)WeatherRefreshWorker.refreshNow(c,false);
    }
}
