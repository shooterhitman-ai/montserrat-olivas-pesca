package com.montserratolivas.pesca;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;

/** Preferencias persistentes compartidas por el dashboard, alarmas, widget y tarea meteorológica. */
public final class AppSettings {
    private AppSettings() { }
    public static SharedPreferences prefs(Context c) { return c.getSharedPreferences("pesca", Context.MODE_PRIVATE); }
    private static int clamp(int n, int min, int max) { return Math.max(min, Math.min(max, n)); }

    public static JSONObject read(Context c) {
        SharedPreferences p = prefs(c);
        JSONObject j = new JSONObject();
        try {
            j.put("alertsEnabled", p.getBoolean("alerts_enabled", true));
            j.put("leadHours", p.getInt("lead_hours", 1));
            j.put("maxAlerts", p.getInt("max_alerts", 0));
            j.put("minScore", p.getInt("min_score", 65));
            j.put("showAllHours", p.getBoolean("show_all_hours", false));
            j.put("weatherAlerts", p.getBoolean("weather_alerts", true));
            j.put("favorableAlerts", p.getBoolean("favorable_alerts", true));
            j.put("weatherLeadHours", p.getInt("weather_lead_hours", 24));
            j.put("weatherCheckHours", p.getInt("weather_check_hours", 6));
            j.put("gustLimit", p.getInt("gust_limit", 55));
            j.put("rainLimit", p.getInt("rain_limit", 80));
            j.put("waveLimit", p.getInt("wave_limit", 3));
            j.put("widgetHours", p.getBoolean("widget_hours", true));
            j.put("widgetWeather", p.getBoolean("widget_weather", true));
            j.put("widgetCompact", p.getBoolean("widget_compact", false));
            j.put("widgetFontScale", p.getInt("widget_font_scale", 110));
            j.put("widgetTheme", p.getString("widget_theme", "ocean"));
            j.put("showBackground", p.getBoolean("show_background", true));
            j.put("compactView", p.getBoolean("compact_view", false));
            j.put("theme", p.getString("theme", "ocean"));
            j.put("windUnit", p.getString("wind_unit", "kmh"));
            j.put("rainUnit", p.getString("rain_unit", "mm"));
            j.put("distanceUnit", p.getString("distance_unit", "km"));
            j.put("tempUnit", p.getString("temp_unit", "c"));
            j.put("timeFormat", p.getString("time_format", "24h"));
            j.put("mapLayer", p.getString("map_layer", "street"));
            j.put("autoGpsOnOpen", p.getBoolean("auto_gps_on_open", true));
            j.put("autoGpsMinDistance", p.getInt("auto_gps_min_distance", 1000));
            j.put("fishingMode", p.getString("fishing_mode", "coast"));
            j.put("lastWeatherCheck", p.getLong("last_weather_check", 0L));
        } catch (Exception ignored) { }
        return j;
    }

    public static void save(Context c, String json) {
        try {
            JSONObject j = new JSONObject(json);
            SharedPreferences.Editor e = prefs(c).edit();
            e.putBoolean("alerts_enabled", j.optBoolean("alertsEnabled", true));
            int fallbackHours = Math.max(0, j.optInt("leadMinutes", 60) / 60);
            e.putInt("lead_hours", clamp(j.optInt("leadHours", fallbackHours), 0, 336));
            e.putInt("max_alerts", clamp(j.optInt("maxAlerts", 0), 0, 24));
            e.putInt("min_score", clamp(j.optInt("minScore", 65), 0, 100));
            e.putBoolean("show_all_hours", j.optBoolean("showAllHours", false));
            e.putBoolean("weather_alerts", j.optBoolean("weatherAlerts", true));
            e.putBoolean("favorable_alerts", j.optBoolean("favorableAlerts", true));
            e.putInt("weather_lead_hours", clamp(j.optInt("weatherLeadHours", 24), 0, 168));
            int checkHours = j.optInt("weatherCheckHours", 6);
            e.putInt("weather_check_hours", checkHours == 3 || checkHours == 12 ? checkHours : 6);
            e.putInt("gust_limit", clamp(j.optInt("gustLimit", 55), 25, 120));
            e.putInt("rain_limit", clamp(j.optInt("rainLimit", 80), 20, 100));
            e.putInt("wave_limit", clamp(j.optInt("waveLimit", 3), 1, 8));
            e.putBoolean("widget_hours", j.optBoolean("widgetHours", true));
            e.putBoolean("widget_weather", j.optBoolean("widgetWeather", true));
            e.putBoolean("widget_compact", j.optBoolean("widgetCompact", false));
            e.putInt("widget_font_scale", clamp(j.optInt("widgetFontScale", 110), 85, 140));
            String widgetTheme = j.optString("widgetTheme", "ocean");
            e.putString("widget_theme", widgetTheme.equals("night") || widgetTheme.equals("forest") ? widgetTheme : "ocean");
            e.putBoolean("show_background", j.optBoolean("showBackground", true));
            e.putBoolean("compact_view", j.optBoolean("compactView", false));
            String theme = j.optString("theme", "ocean");
            e.putString("theme", theme.equals("night") || theme.equals("forest") ? theme : "ocean");
            String windUnit = j.optString("windUnit", "kmh");
            e.putString("wind_unit", windUnit.equals("knots") || windUnit.equals("mph") || windUnit.equals("ms") ? windUnit : "kmh");
            e.putString("rain_unit", "in".equals(j.optString("rainUnit", "mm")) ? "in" : "mm");
            e.putString("distance_unit", "mi".equals(j.optString("distanceUnit", "km")) ? "mi" : "km");
            String tempUnit = j.optString("tempUnit", "c");
            e.putString("temp_unit", tempUnit.equals("f") ? "f" : "c");
            String timeFormat = j.optString("timeFormat", "24h");
            e.putString("time_format", timeFormat.equals("12h") ? "12h" : "24h");
            String mapLayer = j.optString("mapLayer", "street");
            e.putString("map_layer", (mapLayer.equals("topo") || mapLayer.equals("sat")) ? mapLayer : "street");
            e.putBoolean("auto_gps_on_open", j.optBoolean("autoGpsOnOpen", true));
            int gpsDistance = j.optInt("autoGpsMinDistance", 1000);
            e.putInt("auto_gps_min_distance", gpsDistance == 500 || gpsDistance == 3000 || gpsDistance == 5000 ? gpsDistance : 1000);
            e.putString("fishing_mode", j.optString("fishingMode", "coast").equals("inland") ? "inland" : "coast");
            e.apply();
            FishingScheduler.restore(c);
            WeatherRefreshWorker.schedule(c);
            MoonWidget.refresh(c);
        } catch (Exception ignored) { }
    }
}
