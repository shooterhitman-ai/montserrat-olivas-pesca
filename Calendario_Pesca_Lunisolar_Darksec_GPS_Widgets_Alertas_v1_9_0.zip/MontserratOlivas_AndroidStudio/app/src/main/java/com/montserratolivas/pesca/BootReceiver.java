package com.montserratolivas.pesca;
import android.content.*;
public class BootReceiver extends android.content.BroadcastReceiver {@Override public void onReceive(Context c,Intent i){FishingScheduler.restore(c);WeatherRefreshWorker.schedule(c); WeatherRefreshWorker.refreshNow(c,false); MoonWidget.refresh(c); PotentialWidget.refresh(c);}}
