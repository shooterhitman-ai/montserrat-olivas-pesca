package com.montserratolivas.pesca;

import android.app.Activity;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.util.Locale;

final class SpeechReader {
    interface State { void update(String value); }
    private final Activity activity;
    private final State state;
    private TextToSpeech engine;
    private boolean ready=false, closed=false;
    private String pending="", current="";
    private int serial=0;
    SpeechReader(Activity activity, State state){this.activity=activity;this.state=state;}
    void speak(String text){
        if(closed||text==null)return;
        pending=text.substring(0,Math.min(3500,text.length()));
        if(engine==null){
            engine=new TextToSpeech(activity, result->activity.runOnUiThread(()->{
                if(closed)return;
                if(result!=TextToSpeech.SUCCESS){pending="";state.update("error");return;}
                int language=engine.setLanguage(new Locale("es","MX"));
                if(language<0)language=engine.setLanguage(new Locale("es"));
                if(language<0){pending="";state.update("error");return;}
                ready=true;
                engine.setOnUtteranceProgressListener(new UtteranceProgressListener(){
                    private void report(String id,String value){activity.runOnUiThread(()->{if(!closed&&id.equals(current))state.update(value);});}
                    @Override public void onStart(String id){report(id,"reading");}
                    @Override public void onDone(String id){report(id,"done");}
                    @Override public void onError(String id){report(id,"error");}
                });
                play();
            }));
        }else if(ready)play();
        else state.update("error");
    }
    private void play(){
        if(!ready||pending.isEmpty()||closed)return;
        String text=pending;pending="";current="reading-"+(++serial);
        if(engine.speak(text,TextToSpeech.QUEUE_FLUSH,null,current)==TextToSpeech.ERROR)state.update("error");
    }
    void stop(){pending="";current="";if(engine!=null)engine.stop();state.update("stopped");}
    void close(){stop();closed=true;if(engine!=null){engine.shutdown();engine=null;}}
}
