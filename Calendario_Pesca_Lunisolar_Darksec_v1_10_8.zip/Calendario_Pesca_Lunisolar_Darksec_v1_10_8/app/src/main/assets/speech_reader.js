(() => {
  const status=()=>document.getElementById('readerStatus');
  window.darksecReadState=state=>{const el=status();if(el)el.textContent=state==='reading'?'Leyendo…':state==='error'?'No se pudo leer. Comprueba que Android tenga una voz en español.':'';};
  window.darksecStopSpeaking=()=>{try{window.PescaAndroid?.stopReading?.();window.speechSynthesis?.cancel();}catch(_){}window.darksecReadState('stopped');};
  window.darksecSpeak=text=>{
    window.darksecStopSpeaking();const value=String(text||'').slice(0,3500);if(!value)return;
    if(window.PescaAndroid?.speakText){window.PescaAndroid.speakText(value);return;}
    if(window.speechSynthesis&&window.SpeechSynthesisUtterance){const utterance=new SpeechSynthesisUtterance(value);utterance.lang='es-MX';utterance.onstart=()=>window.darksecReadState('reading');utterance.onend=()=>window.darksecReadState('done');utterance.onerror=()=>window.darksecReadState('error');window.speechSynthesis.speak(utterance);}else window.darksecReadState('error');
  };
  document.addEventListener('visibilitychange',()=>{if(document.hidden)window.darksecStopSpeaking();});
})();
