(() => {
  const $=id=>document.getElementById(id), panel=$('wikiPanel'), input=$('wikiQuery'), status=$('wikiStatus'), list=$('wikiResults'), detail=$('wikiDetail');
  if(!panel)return;
  let location=null, sequence=0, controller, detailController, markers=null;
  const cache=new Map();
  let autoTimer, readable="";
  window.darksecWikiRead=()=>{if(readable)window.darksecSpeak?.(readable);};
  $('wikiRead').onclick=window.darksecWikiRead;$('wikiStop').onclick=()=>window.darksecStopSpeaking?.();
  const articleUrl=id=>'https://es.wikipedia.org/?curid='+Number(id);
  function clearMarkers(){if(markers){markers.clearLayers();}}
  async function api(params,signal){
    const url='https://es.wikipedia.org/w/api.php?'+new URLSearchParams({action:'query',format:'json',origin:'*',...params});
    if(cache.has(url))return cache.get(url);
    const response=await fetch(url,{signal});if(!response.ok)throw Error('Wikipedia no respondió');
    const data=await response.json();if(data.error)throw Error('Wikipedia no pudo procesar la consulta');
    if(cache.size>=40)cache.delete(cache.keys().next().value);cache.set(url,data);return data;
  }
  function invalidate(){clearTimeout(autoTimer);window.darksecStopSpeaking?.();readable="";$('wikiRead').disabled=true;sequence++;controller?.abort();detailController?.abort();list.replaceChildren();detail.replaceChildren();detail.hidden=true;clearMarkers();}
  window.darksecWikiLocationChanged=(lat,lon,name)=>{
    invalidate();location=Number.isFinite(lat)&&Number.isFinite(lon)&&Math.abs(lat)<=90&&Math.abs(lon)<=180?{lat,lon}:null;
    input.value=name||'';status.textContent='Buscando información del punto…';autoTimer=setTimeout(()=>search({auto:true}),650);
  };
  async function showArticle(item, speak=false){
    window.darksecStopSpeaking?.();readable="";$('wikiRead').disabled=true;
    detailController?.abort();const control=new AbortController();detailController=control;
    const id=sequence,timer=setTimeout(()=>control.abort(),12000);
    detail.hidden=false;detail.replaceChildren();detail.textContent='Cargando artículo…';
    try{
      const data=await api({prop:'extracts',pageids:String(item.pageid),exintro:'1',explaintext:'1',exchars:'1200',redirects:'1'},control.signal);
      if(id!==sequence||control.signal.aborted)return;
      const page=Object.values(data.query?.pages||{})[0];
      detail.replaceChildren();const title=document.createElement('h3');title.textContent=page?.title||item.title;
      const note=document.createElement('p');note.className='tiny';note.textContent=item.context;
      const text=document.createElement('p');text.textContent=page?.extract||'No hay un resumen disponible. Abre el artículo completo.';
      const link=document.createElement('a');link.href=articleUrl(item.pageid);link.target='_blank';link.rel='noopener';link.textContent='Leer artículo completo en Wikipedia';
      detail.append(title,note,text,link);
      readable=page?.extract ? "Wikipedia: "+(page.title||item.title)+". "+item.context+". "+page.extract : "";
      $('wikiRead').disabled=!readable;
      if(speak&&readable)window.darksecSpeak?.(readable);
    }catch(e){if(id===sequence&&detailController===control){detail.textContent='No se pudo cargar el resumen. Vuelve a tocar el artículo para reintentar.';}}
    finally{clearTimeout(timer);}
  }
  async function search(options={}){
    const term=input.value.trim();invalidate();const id=sequence;
    if(!term&&!location){status.textContent='Selecciona primero un lugar en el mapa.';if(options.speak)window.darksecSpeak?.(status.textContent);return;}
    const control=new AbortController();controller=control;const timer=setTimeout(()=>control.abort(),12000);
    status.textContent='Consultando Wikipedia…';
    const requests=[];
    if(term)requests.push(api({list:'search',srsearch:term,srlimit:'5',srnamespace:'0'},control.signal).then(d=>(d.query?.search||[]).map(p=>({...p,context:'Resultado por nombre'}))));
    if(location && (!options.speak || !term))requests.push(api({list:'geosearch',gscoord:location.lat+'|'+location.lon,gsradius:'10000',gslimit:'10',gsnamespace:'0'},control.signal).then(d=>(d.query?.geosearch||[]).map(p=>({...p,context:'Artículo cercano · '+(p.dist/1000).toFixed(1)+' km'}))));
    try{
      const batches=await Promise.allSettled(requests);if(id!==sequence)return;
      const pages=batches.flatMap(r=>r.status==='fulfilled'?r.value:[]).filter(p=>Number.isInteger(p.pageid)&&p.pageid>0);
      const unique=pages.filter((p,i,all)=>all.findIndex(q=>q.pageid===p.pageid)===i);
      if(window.darksecMap&&window.L&&!markers)markers=window.L.layerGroup().addTo(window.darksecMap);
      for(const item of unique){
        const button=document.createElement('button');button.type='button';button.textContent=item.title+' — '+item.context;button.onclick=()=>showArticle(item);list.append(button);
      }
      // Nearby coordinates belong to articles, not necessarily the selected river or lake.
      for(const item of pages.filter(p=>Number.isFinite(p.lat)&&Number.isFinite(p.lon))){
        if(markers){const popup=document.createElement('button');popup.type='button';popup.textContent='Wikipedia: '+item.title;popup.onclick=()=>{showArticle(item);panel.scrollIntoView({behavior:'smooth',block:'nearest'});};window.L.marker([item.lat,item.lon]).bindPopup(popup).addTo(markers);}
      }
      const failed=batches.some(r=>r.status==='rejected');
      status.textContent=unique.length?'Selecciona un artículo para leer su resumen.'+(failed?' Una consulta no respondió; puedes reintentar.':''):failed?'No se pudo consultar Wikipedia. Comprueba internet y reintenta.':'No encontramos artículos. Prueba otro nombre; algunos ríos y lagunas no tienen artículo o coordenadas en Wikipedia.';
      if(unique.length){const nearby=pages.filter(p=>Number.isFinite(p.dist)).sort((a,b)=>a.dist-b.dist);const normalize=t=>String(t).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();const byName=term?unique.find(p=>normalize(p.title)===normalize(term.split(',')[0])):null;await showArticle(options.auto?(byName||nearby[0]||unique[0]):unique[0],!!options.speak);}
      else if(options.speak)window.darksecSpeak?.(status.textContent);
    }catch(e){if(id===sequence)status.textContent='No se pudo cargar la información. Pulsa Consultar Wikipedia para reintentar.';}finally{clearTimeout(timer);}
  }
  window.darksecWikiSearch=(term,options={})=>{input.value=term||'';panel.scrollIntoView({behavior:'smooth',block:'nearest'});search(options);};
  $('wikiSearch').onclick=search;input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();search();}});
  if(window.darksecPlaceName || (typeof locationConfirmed!=='undefined' && locationConfirmed)){location={lat:window.darksecCurrentLat,lon:window.darksecCurrentLon};input.value=window.darksecPlaceName||'';}
})();
