(() => {
  function parse(text) {
    let value=String(text||'').trim().replace(/[¿?¡!]/g,'').replace(/^por favor[, ]+/i,'').replace(/[, ]+por favor[.!]?$/i,'').trim();
    value=value.replace(/^(?:puedes|podrías|podrias)\s+/i,'');
    const plain=value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    if(/^(?:(?:usa|usar|activa|activar) (?:el |mi )?)?(?:gps|mi ubicacion|ubicacion actual|mi ubicacion actual)$/.test(plain)) return {action:'gps'};
    if(/^(?:guarda|guardar) (?:este lugar|esta zona|mi ubicacion)(?: (?:en|como) favoritos?)?$/.test(plain)) return {action:'save'};
    if(/^(?:lee|leer|escuchar|lee el resumen|lee el articulo|leelo|lee esto)$/.test(plain))return {action:'read'};
    if(/^(?:para|detente|silencio|detener|deja de leer)$/.test(plain))return {action:'stop'};
    const numbered=plain.match(/^(?:(?:el|la|resultado|numero|opcion) )?(uno|dos|tres|cuatro|cinco)$/);if(numbered)return {action:'choose',index:['uno','dos','tres','cuatro','cinco'].indexOf(numbered[1])};
    const choice=plain.replace(/^(?:llevame|ve) al /,'el ').match(/^(?:(?:el|la|resultado|numero|opcion) )?(primero|primera|segundo|segunda|tercero|tercera|cuarto|cuarta|quinto|quinta|[1-9]|1[0-9]|20)$/);
    if(choice){const names=['primero','primera','segundo','segunda','tercero','tercera','cuarto','cuarta','quinto','quinta'];return {action:'choose',index: names.includes(choice[1])?Math.floor(names.indexOf(choice[1])/2):Number(choice[1])-1};}
    if(/^(?:que es|como es|hablame de|cuentame de|que sabes de) (?:aqui|este lugar|esta zona)$/.test(plain))return {action:'info',query:''};
    const where=value.match(/^d[oó]nde (?:est[aá]|queda|se encuentra)\s+(.+)$/i);if(where)return {action:'search',query:where[1]};
    const question=value.match(/^(?:qu[eé] es|c[oó]mo es|qu[eé] significa)\s+(.+)$/i);if(question)return {action:'info',query:question[1]};
    const info=value.match(/^(?:qu[eé] sabes (?:de|sobre)|(?:dame |muestra |mu[eé]strame )?informaci[oó]n (?:de|sobre)|cu[eé]ntame (?:de|sobre)|h[aá]blame (?:de|sobre)|wikipedia(?: de| sobre)?)\s+(.+)$/i);
    if(info) return {action:'info',query:info[1].trim()};
    if(/^(?:que|como|cuando|por que|quien|cuanto|cuantos|cual)\b/.test(plain))return {action:'unknown'};
    value=value.replace(/^(?:busca(?:r|me)?|b[uú]scame|encuentra|ll[eé]vame|quiero ir|mu[eé]strame)(?:\s+(?:a|en))?\s+/i,'').trim();
    return {action:'search',query:value};
  }
  window.DarksecVoiceCommands={parse};
})();
