(() => {
  const words=text=>String(text||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().split(/[^a-z0-9]+/).filter(x=>x.length>1&&!['el','la','los','las','de','del','en','municipio','estado'].includes(x));
  function matches(place,query){
    const parts=String(query).split(',');
    const all=words(place.name),local=words(place.primaryName||place.name.split(',')[0]);
    const requested=words(query);if(!requested.length)return false;
    const contains=(haystack,term)=>haystack.some(word=>word===term);
    if(!requested.every(t=>contains(all,t)))return false;
    return parts.length<2 || words(parts[0]).every(t=>contains(local,t));
  }
  window.DarksecPlaceMatch={matches};
})();
