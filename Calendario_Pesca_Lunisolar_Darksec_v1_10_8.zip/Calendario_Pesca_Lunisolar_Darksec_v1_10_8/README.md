# Calendario Pesca Lunisolar Darksec 1.10.8

Proyecto Android Studio listo para GitHub Actions. Conserva GPS, fases lunares, calendarios, widgets y avisos de pesca/clima.

## Novedades 1.10.8
- Fichas de temperatura, lluvia y viento con tipografía pareja, centrada y protegida contra recortes.
- Escala de texto del widget ajustada a 85–120 % para evitar desbordes; valores extensos se acortan con puntos suspensivos.

- Las tres gráficas sincronizan la hora seleccionada al tocar o deslizar y regresan a AHORA después de 8 segundos.
- El índice muestra categorías con etiquetas y colores: Favorable, Precaución, Riesgo meteorológico e Índice bajo.
- El detalle de la hora seleccionada incluye sensación térmica, ráfagas, probabilidad e intensidad de lluvia.
- Compara la hora seleccionada con la hora actual.
- Conserva búsqueda geográfica y por voz, favoritos, clima ampliado y unidades 12/24 h, °C/°F.

## Compilar APK desde Android con GitHub

1. Abre el repositorio `shooterhitman-ai/montserrat-olivas-pesca` en GitHub.
2. Sube `Calendario_Pesca_Lunisolar_Darksec_v1_10_8.zip` a la raíz del repositorio y confirma el cambio en `main`. Si estás actualizando el repositorio de esta app, conserva el workflow `.github/workflows/android-apk.yml`.
3. Entra en **Actions**, abre **Compilar APK Android - Lunisolar Darksec** y espera a que termine. También puedes iniciar la compilación con **Run workflow**.
4. En la ejecución, abre **Artifacts** y descarga `Lunisolar-Darksec-APK-v1.10.8`. Extrae el archivo y toca `app-debug.apk` para instalarlo.
5. Si Android lo solicita, permite a Archivos o al navegador instalar aplicaciones. La versión 1.10.8 incrementa el código a 17 para actualizar sobre la 1.10.2.

## Compilación local

Requiere JDK 17 y Gradle 8.9. Desde la raíz del proyecto ejecuta `gradle assembleDebug`; el APK queda en `app/build/outputs/apk/debug/app-debug.apk`. La APK debug sirve para instalar y probar; para Google Play se necesita una compilación release firmada.
