(() => {
  function parse(text) {
    let value=String(text||'').trim().replace(/[¿?¡!]/g,'').replace(/^por favor[, ]+/i,'').replace(/[, ]+por favor[.!]?$/i,'').trim();
    const plain=value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    if(/^(?:(?:usa|usar|activa|activar) (?:el |mi )?)?(?:gps|mi ubicacion|ubicacion actual|mi ubicacion actual)$/.test(plain)) return {action:'gps'};
    if(/^(?:guarda|guardar) (?:este lugar|esta zona|mi ubicacion)(?: (?:en|como) favoritos?)?$/.test(plain)) return {action:'save'};
    const info=value.match(/^(?:qu[eé] sabes (?:de|sobre)|(?:dame |muestra |mu[eé]strame )?informaci[oó]n (?:de|sobre)|cu[eé]ntame (?:de|sobre)|h[aá]blame (?:de|sobre)|wikipedia(?: de| sobre)?)\s+(.+)$/i);
    if(info) return {action:'info',query:info[1].trim()};
    value=value.replace(/^(?:busca(?:r|me)?|b[uú]scame|encuentra|ll[eé]vame|quiero ir|mu[eé]strame)(?:\s+(?:a|en))?\s+/i,'').trim();
    return {action:'search',query:value};
  }
  window.DarksecVoiceCommands={parse};
})();
