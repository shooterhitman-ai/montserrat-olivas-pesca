const fs=require('fs'),vm=require('vm'),assert=require('assert');
const nodes=new Map();function node(){return {value:'',textContent:'',children:[],addEventListener(){},replaceChildren(){this.children=[]},append(...x){this.children.push(...x)},after(){},focus(){},classList:{},click(){this.clicked=true}}}const by=id=>{if(!nodes.has(id))nodes.set(id,node());return nodes.get(id)};
let urls=[];const context={document:{getElementById:by,createElement:node},window:{},localStorage:{getItem(){return null},setItem(){},removeItem(){}},console,Number,Date,Map,Set,Promise,AbortController,setTimeout,clearTimeout,encodeURIComponent,prompt:()=>null,fetch:async url=>{urls.push(url);return {ok:true,json:async()=>url.includes('photon')?{features:[{properties:{name:'El Zapotal',city:'Tamiahua',state:'Veracruz',country:'México'},geometry:{coordinates:[-97.5,21.2]}}]}:{results:[]}}}};
vm.createContext(context);vm.runInContext(fs.readFileSync('app/src/main/assets/voice_commands.js','utf8'),context);vm.runInContext(fs.readFileSync('app/src/main/assets/location_search.js','utf8'),context);
(async()=>{
context.window.darksecVoiceResult(['Llévame a El Zapotal, Tamiahua','Busca El Zapotal Veracruz']);
await new Promise(r=>setTimeout(r,40));assert.equal(by('mapSearchQuery').value,'El Zapotal, Tamiahua');assert.equal(urls.length,2);assert(by('mapSearchResults').children[0].textContent.includes('Veracruz'));
context.window.darksecVoiceResult('usar GPS');assert(by('gps').clicked);
context.window.darksecVoiceResult('21.2, -97.5');assert(by('mapSearchResults').children[0].textContent.includes('21.2'));
context.window.darksecVoiceResult('91, 20');assert(by('mapSearchStatus').textContent.includes('fuera de rango'));
console.log('PASS: voice alternatives, command extraction, both providers, locality labels, GPS, coordinates and range validation');
})().catch(e=>{console.error(e);process.exitCode=1});
