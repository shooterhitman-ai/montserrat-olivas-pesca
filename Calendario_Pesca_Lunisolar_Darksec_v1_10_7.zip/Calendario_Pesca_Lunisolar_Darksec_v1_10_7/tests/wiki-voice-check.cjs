const fs=require('fs'),vm=require('vm'),assert=require('assert');
function element(){return {value:'',textContent:'',children:[],hidden:false,append(...items){this.children.push(...items)},replaceChildren(){this.children=[];this.textContent=''},addEventListener(){},scrollIntoView(){}}}
const nodes=new Map(),get=id=>{if(!nodes.has(id))nodes.set(id,element());return nodes.get(id)};
const context={window:{},document:{getElementById:get,createElement:element},AbortController,URLSearchParams,setTimeout,clearTimeout,console,fetch:async url=>({ok:true,json:async()=>url.includes('list=search')?{query:{search:[{pageid:1,title:'Laguna de Tamiahua'}]}}:url.includes('list=geosearch')?{query:{geosearch:[{pageid:2,title:'Otro lugar',dist:1200,lat:21,lon:-97}]}}:{query:{pages:{1:{title:'Laguna de Tamiahua',extract:'Texto de prueba <script> no ejecutable'}}}}})};
vm.createContext(context);
vm.runInContext(fs.readFileSync('app/src/main/assets/voice_commands.js','utf8'),context);
const parse=context.window.DarksecVoiceCommands.parse;
assert.equal(parse('¿Qué sabes de la laguna de Tamiahua?').action,'info');
assert.equal(parse('Dame información sobre el río Pánuco').query,'el río Pánuco');
assert.equal(parse('usa mi ubicación').action,'gps');
assert.equal(parse('guarda este lugar').action,'save');
assert.equal(parse('por favor búscame Tamiahua Veracruz').query,'Tamiahua Veracruz');
vm.runInContext(fs.readFileSync('app/src/main/assets/place_wikipedia.js','utf8'),context);
(async()=>{
context.window.darksecWikiLocationChanged(21,-97,'Tamiahua');
context.window.darksecWikiSearch('Laguna de Tamiahua');await new Promise(r=>setTimeout(r,20));
assert.equal(get('wikiResults').children.length,2);assert(get('wikiResults').children[0].textContent.includes('verifica'));
await get('wikiResults').children[0].onclick();assert(get('wikiDetail').children[2].textContent.includes('<script>'));assert(get('wikiDetail').children[3].href.endsWith('curid=1'));
context.window.darksecWikiLocationChanged(20,-98,'Nuevo punto');assert.equal(get('wikiResults').children.length,0);assert(get('wikiDetail').hidden);
console.log('PASS: voice intents, Wikipedia name/nearby distinction, plain-text preview, attribution link, reset on location change');
})().catch(e=>{console.error(e);process.exitCode=1});
