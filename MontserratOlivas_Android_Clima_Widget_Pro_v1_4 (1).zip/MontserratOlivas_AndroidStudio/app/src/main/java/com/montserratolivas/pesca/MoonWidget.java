package com.montserratolivas.pesca;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Widget de resumen: no realiza consultas propias; solo muestra el último pronóstico guardado. */
public class MoonWidget extends AppWidgetProvider {
    public static void refresh(Context c) {
        AppWidgetManager manager = AppWidgetManager.getInstance(c);
        int[] ids = manager.getAppWidgetIds(new ComponentName(c, MoonWidget.class));
        if (ids != null && ids.length > 0) new MoonWidget().onUpdate(c, manager, ids);
    }
    private static String niceTime(long epoch) {
        return new SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(new Date(epoch));
    }
    private static String eventDate(JSONObject event, long now) {
        long stamp = event.optLong("epochMs", 0);
        if (stamp <= now) return "";
        String forecastDay = event.optString("day", "");
        String displayDay = forecastDay.length() == 10
            ? forecastDay.substring(8, 10) + "/" + forecastDay.substring(5, 7)
            : "Próx.";
        String hour = event.optString("hour", "—");
        return displayDay + "  " + hour + "     " + event.optInt("score") + "/100";
    }
    @Override public void onUpdate(Context c, AppWidgetManager manager, int[] ids) {
        SharedPreferences p = AppSettings.prefs(c);
        double days = (System.currentTimeMillis()/86400000.0-10957.5-5.2597) % 29.530588853;
        if (days < 0) days += 29.530588853;
        String[] names = {"Nueva", "Creciente", "Cuarto creciente", "Gibosa creciente", "Llena", "Gibosa menguante", "Cuarto menguante", "Menguante"};
        String[] symbols = {"🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘"};
        int phase = ((int) Math.round(days / 29.530588853 * 8)) % 8;
        long updated = p.getLong("widget_weather_updated", 0L);
        long age = System.currentTimeMillis() - updated;
        boolean fresh = updated > 0 && age >= 0 && age < 12L * 3600000L;
        String updatedLabel = updated > 0 ? "Act. " + niceTime(updated) : "Sin actualizar";
        String label = p.getString("widget_status", "Sin pronóstico");
        String risk = p.getString("widget_risk_level", "unknown");
        if (!fresh) label = updated > 0 ? "Datos antiguos" : "Sin pronóstico";
        String[] best = {"— Sin horas disponibles", "", ""};
        try {
            JSONArray events = new JSONArray(p.getString("widget_top_events", "[]"));
            int shown = 0;
            long now = System.currentTimeMillis();
            int minScore = p.getInt("min_score", 65);
            for(int i=0;i<events.length() && shown<3;i++) {
                JSONObject e = events.optJSONObject(i);
                if(e == null || e.optInt("score",-1) < minScore || e.optLong("epochMs",0) <= now) continue;
                String formatted = eventDate(e,now);
                if (formatted.isEmpty()) continue;
                if(shown == 0) best[0] = formatted;
                else best[shown] = formatted;
                shown++;
            }
        } catch (Exception ignored) { }
        boolean showHours = p.getBoolean("widget_hours", true);
        String theme = p.getString("widget_theme", "ocean");
        int background = "forest".equals(theme) ? R.drawable.widget_background_forest
            : "night".equals(theme) ? R.drawable.widget_background_night : R.drawable.widget_background;
        int statusColor = !fresh ? Color.rgb(186, 205, 218)
            : "bad".equals(risk) ? Color.rgb(255, 163, 159)
            : "caution".equals(risk) ? Color.rgb(255, 215, 142) : Color.rgb(122, 245, 206);
        for (int id : ids) {
            RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.moon_widget);
            v.setInt(R.id.widget_root, "setBackgroundResource", background);
            v.setTextViewText(R.id.widget_moon, symbols[phase] + " " + names[phase]);
            v.setTextViewText(R.id.widget_subtitle, "Luna aprox. · Pronóstico: Open-Meteo");
            v.setTextViewText(R.id.widget_updated, updatedLabel);
            v.setTextViewText(R.id.widget_status, label);
            v.setTextColor(R.id.widget_status, statusColor);
            v.setTextViewText(R.id.widget_temp, p.getString("widget_temp", "— °C"));
            v.setTextViewText(R.id.widget_rain, p.getString("widget_rain", "— %"));
            v.setTextViewText(R.id.widget_wind, p.getString("widget_wind", "— km/h"));
            v.setViewVisibility(R.id.widget_hours_section, showHours ? View.VISIBLE : View.GONE);
            v.setTextViewText(R.id.widget_hour1, best[0]);
            v.setTextViewText(R.id.widget_hour2, best[1]);
            v.setTextViewText(R.id.widget_hour3, best[2]);
            v.setViewVisibility(R.id.widget_hour2, !best[1].isEmpty() && showHours ? View.VISIBLE : View.GONE);
            v.setViewVisibility(R.id.widget_hour3, !best[2].isEmpty() && showHours ? View.VISIBLE : View.GONE);
            v.setTextViewText(R.id.widget_footnote, "Índice orientativo (no prob. de captura) · Lluvia = prob. meteorológica · Hora local del lugar");
            PendingIntent action = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            v.setOnClickPendingIntent(R.id.widget_root, action);
            manager.updateAppWidget(id, v);
        }
    }
}
