import com.montserratolivas.pesca.PotentialWindow;
import java.time.Instant;
public class PotentialWindowCheck {
    private static void check(boolean result) { if (!result) throw new AssertionError(); }
    public static void main(String[] args) {
        long now=Instant.parse("2026-11-17T05:54:00Z").toEpochMilli();
        check(PotentialWindow.includes(now, Instant.parse("2026-11-17T06:00:00Z").toEpochMilli()));
        check(PotentialWindow.includes(now, now+24L*3600000));
        check(!PotentialWindow.includes(now, now+24L*3600000+1));
        check(!PotentialWindow.includes(now, now));
        check(!PotentialWindow.includes(now, now-3600000));
        check(!PotentialWindow.includes(now, 0));
        System.out.println("PASS: midnight, 24-hour limit, expired and missing timestamps");
    }
}
