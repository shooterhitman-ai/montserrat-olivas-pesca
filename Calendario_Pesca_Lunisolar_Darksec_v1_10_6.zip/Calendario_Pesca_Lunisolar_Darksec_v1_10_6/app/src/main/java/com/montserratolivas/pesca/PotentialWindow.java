package com.montserratolivas.pesca;
/** Ventana móvil, independiente de la medianoche y de la zona horaria. */
public final class PotentialWindow {
    private PotentialWindow() { }
    public static boolean includes(long now, long instant) {
        return instant > now && instant <= now + 24L * 3600000L;
    }
}
