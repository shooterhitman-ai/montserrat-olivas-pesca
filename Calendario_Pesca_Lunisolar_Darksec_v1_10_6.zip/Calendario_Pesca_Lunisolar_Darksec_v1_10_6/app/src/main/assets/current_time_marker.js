(() => {
  const plugin = {
    id: 'darksecCurrentTimeMarker',
    afterDatasetsDraw(chart, _args, options) {
      const times = options?.timestamps;
      if (!Array.isArray(times) || times.length < 2) return;
      const selectedTime = window.darksecForecastSelection;
      const isSelected = Number.isFinite(selectedTime);
      const targetTime = isSelected ? selectedTime : Date.now();
      if (targetTime < times[0] || targetTime > times[times.length - 1]) return;
      let rightIndex = times.findIndex(value => value >= targetTime);
      if (rightIndex < 0) return;
      const leftIndex = Math.max(0, rightIndex - 1);
      rightIndex = Math.min(times.length - 1, leftIndex + 1);
      if (rightIndex === leftIndex) return;
      const leftTime = times[leftIndex], rightTime = times[rightIndex];
      if (!Number.isFinite(leftTime) || !Number.isFinite(rightTime) || rightTime <= leftTime) return;
      const fraction = Math.max(0, Math.min(1, (targetTime - leftTime) / (rightTime - leftTime)));
      const xScale = chart.scales.x;
      const chartArea = chart.chartArea;
      if (!xScale || !chartArea) return;
      const x0 = xScale.getPixelForValue(leftIndex);
      const x1 = xScale.getPixelForValue(rightIndex);
      const x = x0 + (x1 - x0) * fraction;
      if (!Number.isFinite(x)) return;

      const ctx = chart.ctx;
      ctx.save();
      ctx.beginPath();
      ctx.setLineDash(isSelected ? [] : [5, 4]);
      ctx.strokeStyle = isSelected ? '#ffd276' : '#44f3d2';
      ctx.lineWidth = 2;
      ctx.moveTo(x, chartArea.top);
      ctx.lineTo(x, chartArea.bottom);
      ctx.stroke();
      ctx.setLineDash([]);

      let timeLabel = '';
      try {
        timeLabel = new Intl.DateTimeFormat('es-MX', {
          timeZone: options.timeZone || undefined,
          hour: '2-digit',
          minute: '2-digit',
          hourCycle: options.timeFormat === '12h' ? 'h12' : 'h23'
        }).format(new Date(targetTime));
      } catch (_) { }
      const readings = (options.readings || []).map(reading => {
        const values = reading.values;
        if (!Array.isArray(values)) return null;
        const left = values[leftIndex], right = values[rightIndex];
        let value = null;
        if (Number.isFinite(left) && Number.isFinite(right)) value = left + (right - left) * fraction;
        else if (Number.isFinite(left)) value = left;
        else if (Number.isFinite(right)) value = right;
        if (!Number.isFinite(value)) return null;
        const decimals = Number.isInteger(reading.decimals) ? reading.decimals : 0;
        return `${reading.label} ${value.toFixed(decimals)}${reading.unit || ''}`;
      }).filter(Boolean);
      const lines = [`${isSelected ? 'SELECCIÓN' : 'AHORA'}${timeLabel ? ` · ${timeLabel}` : ''}`, readings.join(' · ')].filter(Boolean);
      ctx.font = '700 9px system-ui, sans-serif';
      const width = Math.min(chartArea.right - chartArea.left, Math.max(...lines.map(line => ctx.measureText(line).width)) + 14);
      const height = 8 + lines.length * 12;
      const left = Math.max(chartArea.left, Math.min(x - width / 2, chartArea.right - width));
      const top = chartArea.top + 4;
      ctx.fillStyle = isSelected ? '#765b14' : '#0b6b60';
      ctx.fillRect(left, top, width, height);
      ctx.fillStyle = '#ffffff';
      ctx.textBaseline = 'middle';
      lines.forEach((line, index) => ctx.fillText(line, left + 7, top + 6 + index * 12, width - 14));
      ctx.restore();
    }
  };
  if (window.Chart && !window.Chart.registry.plugins.get(plugin.id)) window.Chart.register(plugin);
  window.DarksecCurrentTimeMarker = plugin;
})();
