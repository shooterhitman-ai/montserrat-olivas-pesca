(() => {
  const byId = id => document.getElementById(id);
  const query = byId('mapSearchQuery');
  const resultsBox = byId('mapSearchResults');
  const status = byId('mapSearchStatus');
  const native = window.PescaAndroid;
  let results = [];
  const storageKey = 'darksec-favorite-places-v1';
  const labelKey = 'darksec-selected-place-v1';

  function readFavorites() {
    try {
      const saved = native?.getSavedPlaces?.();
      if (saved) return JSON.parse(saved);
    } catch (_) { }
    try { return JSON.parse(localStorage.getItem(storageKey) || '[]'); }
    catch (_) { return []; }
  }
  let favorites = readFavorites().filter(p => p && typeof p.name === 'string' && Number.isFinite(+p.lat) && Number.isFinite(+p.lon));
  function persistFavorites() {
    const json = JSON.stringify(favorites);
    try { localStorage.setItem(storageKey, json); } catch (_) { }
    try { native?.saveSavedPlaces?.(json); } catch (_) { }
    renderFavorites();
  }
  function setLabel(name) {
    window.darksecPlaceName = name || '';
    try { if (name) localStorage.setItem(labelKey, name); else localStorage.removeItem(labelKey); } catch (_) { }
    window.updateLocationSummary?.();
  }
  window.darksecClearPlaceLabel = () => setLabel('');
  if (!Number.isFinite(window.darksecCurrentLat)) window.darksecCurrentLat = Number(window.lat);
  if (!Number.isFinite(window.darksecCurrentLon)) window.darksecCurrentLon = Number(window.lon);
  try { window.darksecPlaceName = localStorage.getItem(labelKey) || ''; } catch (_) { }

  function cleanPlace(r) {
    return [r.name, r.admin1, r.country].filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).join(', ');
  }
  function applyPlace(place) {
    const lat = Number(place.lat), lon = Number(place.lon);
    if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return;
    setLabel(place.name || 'Zona guardada');
    window.setPlace(lat, lon);
    setLabel(place.name || 'Zona guardada');
    status.textContent = '📍 Zona seleccionada: ' + (place.name || `${lat.toFixed(4)}, ${lon.toFixed(4)}`);
    resultsBox.replaceChildren();
  }
  function renderResults() {
    resultsBox.replaceChildren();
    results.forEach((place, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = '📍 ' + place.name;
      button.addEventListener('click', () => applyPlace(place));
      resultsBox.append(button);
    });
  }
  async function searchPlaces() {
    const term = query.value.trim();
    if (term.length < 2) { status.textContent = 'Escribe al menos dos caracteres para buscar.'; query.focus(); return; }
    status.textContent = 'Buscando lugares…';
    resultsBox.replaceChildren();
    try {
      const url = 'https://geocoding-api.open-meteo.com/v1/search?name=' + encodeURIComponent(term) + '&count=8&language=es&format=json';
      const response = await fetch(url);
      if (!response.ok) throw new Error('No se pudo conectar al buscador.');
      const data = await response.json();
      results = (data.results || []).map(r => ({ name: cleanPlace(r), lat: Number(r.latitude), lon: Number(r.longitude) }))
        .filter(r => r.name && Number.isFinite(r.lat) && Number.isFinite(r.lon));
      renderResults();
      status.textContent = results.length ? `Elige uno de los ${results.length} lugares encontrados.` : 'No encontré ese lugar. Prueba con otra ciudad o localidad.';
    } catch (e) { status.textContent = (e.message || 'Error al buscar.') + ' Comprueba tu conexión e inténtalo de nuevo.'; }
  }
  function renderFavorites() {
    const box = byId('favoriteList');
    box.replaceChildren();
    favorites.forEach((place, index) => {
      const chip = document.createElement('div');
      chip.className = 'favorite-chip';
      const use = document.createElement('button');
      use.type = 'button'; use.className = 'favorite-use'; use.textContent = '⭐ ' + place.name;
      use.title = 'Usar ' + place.name + ' para el mapa y el pronóstico';
      use.addEventListener('click', () => applyPlace(place));
      const edit = document.createElement('button');
      edit.type = 'button'; edit.className = 'favorite-edit'; edit.textContent = '✎'; edit.setAttribute('aria-label', 'Cambiar nombre de ' + place.name);
      edit.addEventListener('click', () => {
        const name = prompt('Nombre del lugar favorito:', place.name);
        if (name && name.trim()) { favorites[index] = { ...place, name: name.trim().slice(0, 70) }; persistFavorites(); }
      });
      const del = document.createElement('button');
      del.type = 'button'; del.className = 'favorite-delete'; del.textContent = '×'; del.setAttribute('aria-label', 'Eliminar ' + place.name);
      del.addEventListener('click', () => { favorites.splice(index, 1); persistFavorites(); });
      chip.append(use, edit, del); box.append(chip);
    });
  }
  function saveCurrent() {
    if (!Number.isFinite(window.darksecCurrentLat) || !Number.isFinite(window.darksecCurrentLon)) {
      status.textContent = 'Elige primero una zona en el mapa o usa el GPS.';
      return;
    }
    const suggested = window.darksecPlaceName || '';
    const name = prompt('Pon un nombre para esta zona favorita:', suggested);
    if (!name || !name.trim()) return;
    const place = { name: name.trim().slice(0, 70), lat: Number(window.darksecCurrentLat), lon: Number(window.darksecCurrentLon) };
    const duplicate = favorites.findIndex(p => Math.abs(p.lat - place.lat) < 0.0005 && Math.abs(p.lon - place.lon) < 0.0005);
    if (duplicate >= 0) favorites[duplicate] = place; else favorites.push(place);
    favorites = favorites.filter(p => Number.isFinite(p.lat) && Number.isFinite(p.lon)).slice(-100);
    persistFavorites();
    status.textContent = '⭐ Favorito guardado. Puedes usarlo aquí para actualizar mapa y pronóstico.';
  }
  window.darksecVoiceResult = text => { query.value = text || ''; if (query.value) searchPlaces(); };
  window.darksecVoiceError = message => { status.textContent = message || 'No se pudo iniciar la búsqueda por voz. Puedes escribir el lugar.'; };
  byId('mapSearchSubmit').addEventListener('click', searchPlaces);
  query.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); searchPlaces(); } });
  byId('mapSearchVoice').addEventListener('click', () => {
    if (native?.startVoiceSearch) { status.textContent = 'Escuchando… di el nombre de una ciudad o lugar.'; native.startVoiceSearch(); return; }
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) { status.textContent = 'La búsqueda por voz no está disponible aquí. Escribe el lugar en el buscador.'; query.focus(); return; }
    const speech = new Recognition(); speech.lang = 'es-MX'; speech.onresult = e => window.darksecVoiceResult(e.results[0][0].transcript);
    speech.onerror = () => { status.textContent = 'No se reconoció la voz. Escribe el lugar en el buscador.'; };
    speech.start();
  });
  byId('saveFavorite').addEventListener('click', saveCurrent);
  renderFavorites();
  setLabel(window.darksecPlaceName);
})();
