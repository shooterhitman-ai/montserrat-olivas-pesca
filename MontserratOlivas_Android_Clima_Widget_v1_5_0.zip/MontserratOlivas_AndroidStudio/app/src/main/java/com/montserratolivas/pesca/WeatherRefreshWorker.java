package com.montserratolivas.pesca;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.WorkManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

/** Consulta el modelo sin abrir la app, renueva las horas estimadas y avisa de posibles riesgos.
 *  Es un pronóstico: NO sustituye advertencias oficiales, y WorkManager no garantiza puntualidad.
 */
public class WeatherRefreshWorker extends Worker {
    private static final String UNIQUE_NAME = "pesca_revision_pronostico";
    public WeatherRefreshWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }

    public static void schedule(Context c) {
        SharedPreferences p = AppSettings.prefs(c);
        if (!p.getBoolean("location_selected", false)) return;
        int interval = p.getInt("weather_check_hours", 6);
        if (interval != 3 && interval != 12) interval = 6;
        Constraints limits = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(WeatherRefreshWorker.class, interval, TimeUnit.HOURS)
            .setConstraints(limits).build();
        WorkManager.getInstance(c).enqueueUniquePeriodicWork(UNIQUE_NAME, ExistingPeriodicWorkPolicy.UPDATE, request);
    }

    /** One-off refresh: provides real data to widgets even if the WebView is closed/offline. */
    public static void refreshNow(Context c, boolean force) {
        SharedPreferences p = AppSettings.prefs(c);
        if (!p.getBoolean("location_selected", false)) return;
        long updated = p.getLong("widget_weather_updated", 0L);
        long now = System.currentTimeMillis();
        if (!force && updated > 0 && now - updated < 2 * 3600000L) return;
        long lastRequest = p.getLong("widget_last_refresh_request", 0L);
        // Evita bucles al refrescar el widget tras un error de red; WorkManager reintenta por sí solo.
        if (!force && now - lastRequest < 20 * 60000L) return;
        p.edit().putLong("widget_last_refresh_request", now).apply();
        Constraints network = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(WeatherRefreshWorker.class)
            .setConstraints(network).build();
        WorkManager.getInstance(c).enqueueUniqueWork("pesca_widget_ahora", ExistingWorkPolicy.REPLACE, request);
    }

    private static JSONObject getJson(String address) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(address).openConnection();
        conn.setConnectTimeout(15000); conn.setReadTimeout(20000);
        conn.setRequestProperty("Accept", "application/json");
        try {
            if (conn.getResponseCode() != 200) throw new Exception("HTTP " + conn.getResponseCode());
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192]; int n;
                while ((n = in.read(buffer)) != -1) { out.write(buffer, 0, n); if (out.size() > 1500000) throw new Exception("Respuesta demasiado grande"); }
                return new JSONObject(out.toString("UTF-8"));
            }
        } finally { conn.disconnect(); }
    }
    private static Double at(JSONArray a, int i) { return a != null && i >= 0 && i < a.length() && !a.isNull(i) ? a.optDouble(i, Double.NaN) : null; }
    private static Double safe(JSONArray a, int i) { Double x = at(a, i); return x == null || x.isNaN() ? null : x; }
    private static double val(JSONArray a, int i, double fallback) { Double x = safe(a, i); return x == null ? fallback : x; }
    private static boolean severe(int code, double gust, double rainProb, double rain, double wave, int windLimit, int rainLimit, int waveLimit, boolean coast) {
        return code >= 95 || gust >= windLimit || rain >= 5 || (rainProb >= rainLimit && rain >= 1)
            || (coast && wave >= waveLimit);
    }
    private static boolean favorable(int code, double wind, double gust, double rainProb, double rain, double wave, boolean coast) {
        return code >= 0 && code < 50 && wind <= 20 && gust <= 35 && rainProb <= 25 && rain <= .2 && (!coast || wave < 1.5);
    }
    private static long millis(SimpleDateFormat fmt, String localTime) { try { return fmt.parse(localTime).getTime(); } catch (Exception e) { return 0; } }
    private static double daylight(String time, String sunrise, String sunset) {
        try {
            double h = Integer.parseInt(time.substring(11, 13)) + Integer.parseInt(time.substring(14,16))/60.0;
            double rise = Integer.parseInt(sunrise.substring(11,13)) + Integer.parseInt(sunrise.substring(14,16))/60.0;
            double set = Integer.parseInt(sunset.substring(11,13)) + Integer.parseInt(sunset.substring(14,16))/60.0;
            return Math.max(Math.exp(-Math.pow((h-rise)/1.6,2)),Math.exp(-Math.pow((h-set)/1.6,2)));
        } catch (Exception e) { return 0.4; }
    }
    private static int index(double wind, double rainProb, double light, Double wave, boolean coast) {
        double wf=Math.max(0,100-wind*2.4), rf=100-rainProb;
        if (coast && wave!=null) return (int)Math.round(.35*wf+.2*rf+.2*Math.max(0,100-wave*30)+.25*light);
        double total=coast?.35+.2+.25:.45+.25+.30;
        return (int)Math.round((coast?.35*wf+.2*rf+.25*light:.45*wf+.25*rf+.30*light)/total);
    }
    private static void notifyOnce(Context c, String key, String title, String message, int id) {
        SharedPreferences p = AppSettings.prefs(c);
        String history = p.getString("weather_notification_keys", "|");
        if (history.contains("|"+key+"|")) return;
        FishingAlarmReceiver.sendWeather(c, title, message, id);
        history += key + "|";
        if (history.length() > 5000) history = "|" + history.substring(history.length()-4000);
        p.edit().putString("weather_notification_keys",history).apply();
    }

    @NonNull @Override public Result doWork() {
        Context c = getApplicationContext();
        SharedPreferences p = AppSettings.prefs(c);
        if (!p.getBoolean("location_selected", false)) return Result.success();
        double lat = Double.longBitsToDouble(p.getLong("lat_bits", Double.doubleToLongBits(19.4326)));
        double lon = Double.longBitsToDouble(p.getLong("lon_bits", Double.doubleToLongBits(-99.1332)));
        if (lat < -90 || lat > 90 || lon < -180 || lon > 180) return Result.failure();
        String loc = "latitude=" + lat + "&longitude=" + lon + "&timezone=auto&forecast_days=16";
        try {
            JSONObject data = getJson("https://api.open-meteo.com/v1/forecast?" + loc + "&hourly=temperature_2m,precipitation_probability,precipitation,wind_speed_10m,wind_gusts_10m,weather_code&daily=sunrise,sunset");
            JSONObject hourly=data.getJSONObject("hourly"), daily=data.getJSONObject("daily");
            JSONArray time=hourly.getJSONArray("time"),wind=hourly.getJSONArray("wind_speed_10m"),rainProb=hourly.getJSONArray("precipitation_probability");
            JSONArray gust=hourly.optJSONArray("wind_gusts_10m"),rain=hourly.optJSONArray("precipitation"),codes=hourly.optJSONArray("weather_code");
            JSONArray days=daily.getJSONArray("time"),rises=daily.getJSONArray("sunrise"),sets=daily.getJSONArray("sunset");
            boolean coast=p.getString("fishing_mode","coast").equals("coast");
            JSONObject waves=null;
            if (coast) try { waves=getJson("https://marine-api.open-meteo.com/v1/marine?latitude="+lat+"&longitude="+lon+"&timezone=auto&forecast_days=8&hourly=wave_height").getJSONObject("hourly"); } catch(Exception ignored) { }
            JSONArray waveTimes=waves==null?null:waves.optJSONArray("time"), waveValues=waves==null?null:waves.optJSONArray("wave_height");
            SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US);
            fmt.setLenient(false); fmt.setTimeZone(TimeZone.getTimeZone(data.optString("timezone", "America/Mexico_City")));
            JSONArray events=new JSONArray();
            long now=System.currentTimeMillis();
            long upcomingUntil=now + p.getInt("weather_lead_hours",24)*3600000L;
            int gustLimit=p.getInt("gust_limit",55), rainLimit=p.getInt("rain_limit",80), waveLimit=p.getInt("wave_limit",3);
            boolean warnings=p.getBoolean("weather_alerts",true), goodNews=p.getBoolean("favorable_alerts",true);
            int warningCount=0; boolean foundFavorable=false;
            String zone=String.format(Locale.US,"%.2f,%.2f",lat,lon);
            int di=0, wi=0;
            for(int i=0;i<time.length();i++) {
                String local=time.optString(i,""), day=local.length()>=10?local.substring(0,10):"";
                while(di<days.length()-1 && day.compareTo(days.optString(di,""))>0)di++;
                while(waveTimes!=null && wi<waveTimes.length()-1 && waveTimes.optString(wi,"").compareTo(local)<0)wi++;
                long instant=millis(fmt,local);
                if(instant<=now)continue;
                double w=val(wind,i,Double.NaN), rp=val(rainProb,i,Double.NaN);
                if(Double.isNaN(w)||Double.isNaN(rp))continue;
                double gu=val(gust,i,0), ra=val(rain,i,0),wv=-1;
                if(waveTimes!=null && local.equals(waveTimes.optString(wi,"")))wv=val(waveValues,wi,-1);
                int code=(int)val(codes,i,-1);
                boolean bad=severe(code,gu,rp,ra,wv,gustLimit,rainLimit,waveLimit,coast);
                double light=daylight(local,rises.optString(di,""),sets.optString(di,""));
                int score=index(w,rp,100*light,wv>=0?wv:null,coast);
                if(!bad) {
                    JSONObject evt=new JSONObject();evt.put("day",day);evt.put("hour",local.substring(11,16));evt.put("epochMs",instant);evt.put("score",score);
                    events.put(evt);
                }
                if(instant > upcomingUntil)continue;
                String keyDay=day+"_"+zone;
                if(bad && warnings && warningCount<2) {
                    String reason=code>=95?"tormenta":gu>=gustLimit?"ráfagas de "+Math.round(gu)+" km/h":ra>=5?"lluvia intensa":rp>=rainLimit && ra>=1?"lluvia probable": "oleaje de "+String.format(Locale.US,"%.1f",wv)+" m";
                    String eventKey="RIESGO_"+reason.replaceAll("[0-9.]","")+"_"+keyDay;
                    String previous=p.getString("weather_notification_keys","|");
                    if(!previous.contains("|"+eventKey+"|")) {
                        notifyOnce(c,eventKey,"⚠ Posibles inclemencias para pescar", day+" "+local.substring(11,16)+": "+reason+". Pronóstico orientativo, consulta alertas oficiales.",8100+warningCount);
                        warningCount++;
                    }
                }
                if(!bad && !foundFavorable && goodNews && favorable(code,w,gu,rp,ra,wv,coast)) {
                    if(instant <= now+12*3600000L) {
                        String goodKey="BUENO_"+keyDay;
                        notifyOnce(c,goodKey,"🎣 Clima estimado favorable", day+" "+local.substring(11,16)+": viento "+Math.round(w)+" km/h y lluvia "+Math.round(rp)+"%. Confirma el pronóstico al salir.",8200);
                        foundFavorable=true;
                    }
                }
            }
            if (p.getLong("lat_bits", 0L) != Double.doubleToLongBits(lat)
                || p.getLong("lon_bits", 0L) != Double.doubleToLongBits(lon)) return Result.success();
            // Resumen del widget: primer pronóstico futuro, con estado de riesgo de las próximas 12 horas.
            int first=-1;
            for(int i=0;i<time.length();i++) { if(millis(fmt,time.optString(i,""))>now){first=i;break;} }
            if(first>=0) {
                String selectedTime = time.optString(first, "");
                double currentTemp = val(hourly.optJSONArray("temperature_2m"), first, Double.NaN);
                double currentRain = val(rainProb, first, Double.NaN);
                double currentWind = val(wind, first, Double.NaN);
                String risk = "good", status = "✓ Favorable";
                for(int j=first;j<time.length();j++) {
                    long hour = millis(fmt,time.optString(j,""));
                    if(hour <= now || hour > now+12*3600000L) continue;
                    double ww=val(wind,j,0),rr=val(rainProb,j,0),gg=val(gust,j,0),ra=val(rain,j,0);
                    int cc=(int)val(codes,j,-1);
                    double wv=-1;
                    if(coast && waveTimes!=null && waveValues!=null) {
                        for(int k=0;k<waveTimes.length();k++) {
                            if(time.optString(j,"").equals(waveTimes.optString(k,""))) {wv=val(waveValues,k,-1);break;}
                        }
                    }
                    if(severe(cc,gg,rr,ra,wv,gustLimit,rainLimit,waveLimit,coast)) { risk="bad"; status="⚠ Riesgo clima"; break; }
                    if(coast && wv>=1.5) {risk="caution";status="! Precaución";}
                    if((cc>=80 && cc<95) || gg>=35 || rr>=50) { risk="caution"; status="! Precaución"; }
                }
                JSONObject snapshot = new JSONObject()
                    .put("updatedAt", System.currentTimeMillis()).put("status", status).put("risk", risk)
                    .put("zone", String.format(Locale.US, "%.3f, %.3f", lat, lon))
                    .put("temp", Double.isNaN(currentTemp)?"— °C":Math.round(currentTemp)+" °C")
                    .put("rain", Double.isNaN(currentRain)?"— %":Math.round(currentRain)+"%")
                    .put("wind", Double.isNaN(currentWind)?"— km/h":Math.round(currentWind)+" km/h");
                WeatherWidgetStore.save(c, snapshot.toString());
            }
            JSONObject schedule=new JSONObject().put("events",events).put("updatedAt",System.currentTimeMillis());
            FishingScheduler.apply(c,schedule.toString(),true);
            p.edit().putLong("last_weather_check",System.currentTimeMillis()).remove("widget_last_error").apply();
            return Result.success();
        } catch(Exception e) {
            p.edit().putString("widget_last_error", "No se pudo actualizar el pronóstico").apply();
            MoonWidget.refresh(c);
            return Result.retry();
        }
    }
}
