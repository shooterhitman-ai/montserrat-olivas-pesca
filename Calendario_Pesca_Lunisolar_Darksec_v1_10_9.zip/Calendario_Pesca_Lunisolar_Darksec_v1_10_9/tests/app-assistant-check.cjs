const fs=require('fs'),vm=require('vm'),assert=require('assert');
const now=Date.parse('2026-11-19T15:00:00Z');class Clock extends Date{static now(){return now;}}
const nodes=new Map();const get=id=>{if(!nodes.has(id))nodes.set(id,{textContent:'',value:'',addEventListener(){}});return nodes.get(id)};
let s={confirmed:true,loading:false,date:'2026-11-19',place:'El Molino, Namiquipa, Chihuahua',fetchedAt:now-1000,
weather:{utc_offset_seconds:0,hourly:{time:['2026-11-19T16:00','2026-11-19T18:00','2026-11-20T08:00','2026-11-20T12:00'],temperature_2m:[20,19,12,22],apparent_temperature:[19,18,11,21],wind_speed_10m:[10,15,9,11],wind_gusts_10m:[20,30,18,22],precipitation_probability:[10,40,5,20],precipitation:[0,1,0,0],relative_humidity_2m:[50,60,70,40]}},
epoch:t=>Date.parse(t+'Z'),time:t=>t.slice(11,16),temp:v=>v+' °C',wind:v=>v+' km/h',rain:v=>v+' mm',wave:()=>null,moon:()=> 'Luna creciente, iluminación aproximada 30 por ciento',score:r=>r.i===1?90:65,risk:i=>({level:i===1?'bad':'good',reasons:[i===1?'ráfagas fuertes':'sin riesgos importantes identificados por el modelo']})};
let spoken='';const context={window:{darksecForecastSnapshot:()=>s,darksecSpeak:t=>{spoken=t}},document:{getElementById:get},Date:Clock,console};vm.createContext(context);vm.runInContext(fs.readFileSync('app/src/main/assets/app_assistant.js','utf8'),context);
vm.runInContext(fs.readFileSync('app/src/main/assets/voice_commands.js','utf8'),context);assert.equal(context.window.DarksecVoiceCommands.parse('cómo está el viento').action,'app');
const answer=context.window.DarksecAppAssistant.answer;
assert(answer('¿Cómo está el viento hoy?').includes('10 km/h'));
assert(answer('¿Y mañana?').includes('2026-11-20'));
assert(answer('temperatura hoy').includes('20 °C'));
assert(answer('cuál es la mejor hora para pescar hoy').includes('16:00'));
assert(!answer('cuál es la mejor hora para pescar hoy').includes('índice 90'));
assert(answer('humedad mañana por la mañana').includes('70 por ciento'));
assert(answer('oleaje hoy').includes('No hay datos'));
assert(answer('clima en Veracruz').includes('selecciónala primero'));
s.loading=true;assert(answer('viento').includes('actualizando'));s.loading=false;
s.fetchedAt=now-7*3600000;assert(answer('va a llover').includes('seis horas'));s.fetchedAt=now;
s.weather.hourly.wind_speed_10m[0]=null;assert(answer('viento hoy').includes('sin dato'));
context.window.darksecAskApp('temperatura hoy');assert.equal(get('appAnswer').textContent,spoken);
s.confirmed=false;assert(answer('clima').includes('Selecciona una ubicación'));
console.log('PASS: real snapshot adapter, spoken answer, units, tomorrow follow-up, morning period, high-risk exclusion, missing/stale/loading data, location context');
