(() => {
  const normalize=t=>String(t||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const topics=/\b(clima|tiempo|temperatura|calor|frio|viento|rafagas|llover|lluvia|precipitacion|humedad|luna|lunar|oleaje|olas|amanecer|atardecer|anochecer|pescar|pesca|indice|riesgo|peligro|pronostico|ubicacion|zona|amanecer|atardecer|sol)\b/;
  let previous='';
  function recognizes(text){const q=normalize(text);return /^(?:y )?(?:hoy|manana|pasado manana)[?¿ ]*$/.test(q)||(/mejor(?:es)? hora(?:s)?/.test(q)||topics.test(q))&&!  /^(?:busca|buscar|buscame|llevame|encuentra|hablame de|que sabes de)\b/.test(q);}
  function answer(question){
    let q=normalize(question).replace(/[¿?]/g,'').trim();
    if(/^(?:y )?(hoy|manana|pasado manana)$/.test(q)){
      if(!previous)return 'Primero dime qué quieres consultar: lluvia, viento, temperatura o mejores horas.';
      q=previous.replace(/pasado manana|manana|hoy/g,'')+' '+q.replace(/^y /,'');
    }
    if(!recognizes(q))return 'Puedo consultar clima, lluvia, viento, temperatura, humedad, Luna, oleaje, riesgos y mejores horas. Para conocer un lugar, dime: qué sabes de, seguido de su nombre.';
    previous=q;
    const s=window.darksecForecastSnapshot?.();
    if(!s||!s.confirmed)return 'Selecciona una ubicación o usa el GPS para consultar tus datos.';
    if(/\b(donde estoy|ubicacion|que zona)\b/.test(q))return 'La zona seleccionada para el pronóstico es '+s.place+'.';
    if(s.loading)return 'Estoy actualizando el pronóstico de la zona. Pregúntame de nuevo cuando termine.';
    const now=Date.now(),offset=Number(s.weather?.utc_offset_seconds)||0;
    const today=new Date(now+offset*1000).toISOString().slice(0,10);
    let day=s.date||today;
    const dateWords=q.replace(/(?:por|en) la manana/g,'');
    if(dateWords.includes('pasado manana'))day=new Date(now+offset*1000+2*86400000).toISOString().slice(0,10);
    else if(dateWords.includes('manana'))day=new Date(now+offset*1000+86400000).toISOString().slice(0,10);
    else if(/\b(hoy|ahora|actual)\b/.test(q))day=today;
    const explicit=q.match(/\b\d{4}-\d{2}-\d{2}\b/);if(explicit)day=explicit[0];
    if(/\b(ayer|semana|mes|lunes|martes|miercoles|jueves|viernes|sabado|domingo)\b/.test(q))return 'Para esa fecha, selecciónala en el calendario y vuelve a preguntarme, o indica la fecha como año-mes-día.';
    const placeAsked=q.match(/\ben (.+)$/);
    if(placeAsked&&!/^(?:este lugar|esta zona|la zona|las proximas|la manana|la tarde|la noche)/.test(placeAsked[1])&&!normalize(s.place).includes(placeAsked[1].trim()))return 'Tengo los datos de '+s.place+'. Para consultar otra localidad, búscala y selecciónala primero en el mapa.';
    const head='Para '+s.place+', el '+day+'. ';
    const sentences=[];
    if(/\b(luna|lunar)\b/.test(q))sentences.push(s.moon(day)+'.');
    const onlyMoon=sentences.length&&!/\b(clima|viento|lluvia|temperatura|pesca|pescar|olas|oleaje|humedad|amanecer|atardecer|riesgo)\b/.test(q);
    if(onlyMoon)return head+sentences.join(' ');
    const h=s.weather?.hourly;
    if(!h?.time?.length||!s.fetchedAt)return 'No tengo un pronóstico disponible. Pulsa Actualizar datos y vuelve a preguntar.';
    if(now-s.fetchedAt>6*3600000)return 'El pronóstico guardado tiene más de seis horas. Actualiza los datos antes de consultar las condiciones.';
    let rows=h.time.map((t,i)=>({t,i})).filter(r=>r.t.slice(0,10)===day);
    if(!rows.length)return head+'No tengo datos para esa fecha.';
    let upcoming=day===today?rows.filter(r=>s.epoch(r.t)>now):rows;
    const period=/\b(por la tarde|en la tarde)\b/.test(q)?[12,19]:/\b(por la noche|en la noche)\b/.test(q)?[19,24]:/\b(por la manana|en la manana)\b/.test(q)?[6,12]:null;
    if(period){rows=rows.filter(r=>+r.t.slice(11,13)>=period[0]&&+r.t.slice(11,13)<period[1]);upcoming=upcoming.filter(r=>rows.includes(r));}
    if(!rows.length)return head+'No hay datos para ese periodo.';
    let chosen=(day===today?upcoming[0]:rows.find(r=>r.t.endsWith('12:00')))||rows[0];
    if(day===today&&!upcoming.length)return head+'Ya no quedan horas futuras de hoy. Pregúntame por mañana.';
    const at=q.match(/\ba las? (\d{1,2})(?::(\d{2}))?(?:\s*(am|pm))?\b/);
    if(at){let hour=+at[1];if(at[3])hour=(hour%12)+(at[3]==='pm'?12:0);const minute=+(at[2]||0);if(hour>23||minute>59)return 'Indica una hora válida.';const slot=String(hour).padStart(2,'0')+':00';chosen=rows.find(r=>r.t.endsWith(slot));if(!chosen)return head+'No tengo datos para esa hora.';}
    const value=(key,i=chosen.i)=>{const v=h[key]?.[i];return Number.isFinite(v)?v:null;};
    const formatted=(v,fn)=>v===null?'sin dato':fn(v);
    const percent=v=>v===null?'sin dato':Math.round(v)+' por ciento';
    const all=/\b(clima|tiempo|resumen|pronostico|condiciones)\b/.test(q);
    const wind=all||/\b(viento|rafagas)\b/.test(q), temp=all||/\b(temperatura|calor|frio|sensacion)\b/.test(q),rain=all||/\b(llover|lluvia|precipitacion)\b/.test(q);
    if(wind||temp||rain||/\b(humedad|olas|oleaje)\b/.test(q))sentences.push('Pronóstico de las '+s.time(chosen.t)+'.');
    if(temp)sentences.push('Temperatura '+formatted(value('temperature_2m'),s.temp)+', sensación térmica '+formatted(value('apparent_temperature'),s.temp)+'.');
    if(wind)sentences.push('Viento '+formatted(value('wind_speed_10m'),s.wind)+', ráfagas '+formatted(value('wind_gusts_10m'),s.wind)+'.');
    if(wind&&/direccion|donde sopla/.test(q)){const direction=value('wind_direction_10m');if(direction!==null)sentences.push('Dirección '+Math.round(direction)+' grados, '+['norte','noreste','este','sureste','sur','suroeste','oeste','noroeste'][Math.round(direction/45)%8]+'.');}
    if(temp&&/maxima|minima|maximo|minimo/.test(q)){const temps=rows.map(r=>value('temperature_2m',r.i)).filter(v=>v!==null);if(temps.length)sentences.push('En las horas disponibles: máxima '+s.temp(Math.max(...temps))+', mínima '+s.temp(Math.min(...temps))+'.');}
    if(rain&&/cuando|a que hora/.test(q)){const wet=(day===today?upcoming:rows).find(r=>(value('precipitation_probability',r.i)??0)>=50||(value('precipitation',r.i)??0)>0);if(wet)sentences.push('La primera hora con precipitación prevista o probabilidad de al menos 50 por ciento es '+s.time(wet.t)+'.');}
    if(rain){sentences.push('Probabilidad de lluvia '+percent(value('precipitation_probability'))+', precipitación '+formatted(value('precipitation'),s.rain)+'.');if(!at){const probs=(day===today?upcoming:rows).map(r=>value('precipitation_probability',r.i)).filter(v=>v!==null);if(probs.length)sentences.push('Probabilidad máxima en '+(day===today?'las horas restantes':'el periodo')+': '+percent(Math.max(...probs))+'.');}}
    if(/\b(humedad)\b/.test(q))sentences.push('Humedad relativa '+percent(value('relative_humidity_2m'))+'.');
    if(/\b(oleaje|olas)\b/.test(q)){const wave=s.wave(chosen.t);sentences.push(Number.isFinite(wave)?'Altura prevista de ola '+wave.toFixed(1)+' metros.':'No hay datos de oleaje para esa hora y zona.');}
    if(/\b(amanecer|atardecer|anochecer|sol)\b/.test(q)){const d=s.weather.daily||{},i=d.time?.indexOf(day)??-1;sentences.push('Amanecer '+(i>=0&&d.sunrise?.[i]?s.time(d.sunrise[i]):'sin dato')+', atardecer '+(i>=0&&d.sunset?.[i]?s.time(d.sunset[i]):'sin dato')+'.');}
    if(/\b(pesca|pescar|indice|mejor hora)\b/.test(q)){
      const candidates=upcoming.map(r=>({...r,score:s.score(r,day),risk:s.risk(r.i,r.t)})).filter(r=>Number.isFinite(r.score)&&r.risk.level!=='bad').sort((a,b)=>b.score-a.score||s.epoch(a.t)-s.epoch(b.t));
      const best=candidates[0];sentences.push(best?'La mejor hora calculada es '+s.time(best.t)+', con índice '+best.score+' de 100.'+(best.risk.level==='caution'?' Hay condiciones de precaución.':'')+' Es un índice orientativo, no probabilidad de captura.':'No encuentro horas con índice disponible sin riesgo meteorológico alto en ese periodo.');
    }
    if(all||/\b(riesgo|peligro|seguro|seguridad)\b/.test(q)){const risk=s.risk(chosen.i,chosen.t);sentences.push('A las '+s.time(chosen.t)+': '+risk.reasons.join(', ')+'.');}
    return head+(sentences.length?sentences.join(' '):'Pregúntame por lluvia, viento, temperatura o mejores horas.');
  }
  window.DarksecAppAssistant={recognizes,answer};
  window.darksecAskApp=question=>{
    const output=document.getElementById('appAnswer');let response;
    try{response=answer(question);}catch(_){response='No pude consultar los datos. Actualiza el pronóstico y vuelve a intentarlo.';}
    if(output)output.textContent=response;window.darksecSpeak?.(response);return response;
  };
  const input=document.getElementById('appQuestion');
  const ask=document.getElementById('appAsk');if(ask)ask.onclick=()=>window.darksecAskApp(input.value);
  if(input)input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();window.darksecAskApp(input.value);}});
  const mic=document.getElementById('appMic');if(mic)mic.onclick=()=>document.getElementById('mapSearchVoice')?.click();
  const stop=document.getElementById('appStop');if(stop)stop.onclick=()=>window.darksecStopSpeaking?.();
})();
