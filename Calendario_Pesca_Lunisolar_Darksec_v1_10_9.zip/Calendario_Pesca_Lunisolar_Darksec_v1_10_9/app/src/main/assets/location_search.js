(() => {
  const byId = id => document.getElementById(id);
  const query = byId('mapSearchQuery');
  const resultsBox = byId('mapSearchResults');
  const status = byId('mapSearchStatus');
  const native = window.PescaAndroid;
  let results = [];
  const storageKey = 'darksec-favorite-places-v1';
  const labelKey = 'darksec-selected-place-v1';

  function readFavorites() {
    try {
      const saved = native?.getSavedPlaces?.();
      if (saved) return JSON.parse(saved);
    } catch (_) { }
    try { return JSON.parse(localStorage.getItem(storageKey) || '[]'); }
    catch (_) { return []; }
  }
  let favorites = readFavorites().filter(p => p && typeof p.name === 'string' && Number.isFinite(+p.lat) && Number.isFinite(+p.lon));
  function persistFavorites() {
    const json = JSON.stringify(favorites);
    try { localStorage.setItem(storageKey, json); } catch (_) { }
    try { native?.saveSavedPlaces?.(json); } catch (_) { }
    renderFavorites();
  }
  function setLabel(name) {
    window.darksecPlaceName = name || '';
    try { if (name) localStorage.setItem(labelKey, name); else localStorage.removeItem(labelKey); } catch (_) { }
    window.updateLocationSummary?.();
  }
  window.darksecClearPlaceLabel = () => setLabel('');
  if (!Number.isFinite(window.darksecCurrentLat)) window.darksecCurrentLat = Number(window.lat);
  if (!Number.isFinite(window.darksecCurrentLon)) window.darksecCurrentLon = Number(window.lon);
  try { window.darksecPlaceName = localStorage.getItem(labelKey) || ''; } catch (_) { }

  function cleanPlace(r) {
    return [r.name, r.admin3, r.admin2, r.admin1, r.country].filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).join(', ');
  }
  function applyPlace(place) {
    const lat = Number(place.lat), lon = Number(place.lon);
    if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return;
    setLabel(place.name || 'Zona guardada');
    window.setPlace(lat, lon);
    setLabel(place.name || 'Zona guardada');
    status.textContent = '📍 Zona seleccionada: ' + (place.name || `${lat.toFixed(4)}, ${lon.toFixed(4)}`);
    resultsBox.replaceChildren();
  }
  function renderResults() {
    resultsBox.replaceChildren();
    results.forEach((place, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = (index+1) + '. ' + place.name;
      button.addEventListener('click', () => applyPlace(place));
      resultsBox.append(button);
    });
  }
  let searchId = 0, activeController, lastSearch = 0;
  const cache = new Map();
  window.darksecCancelSearch=()=>{++searchId;activeController?.abort();};
  function reply(text){status.textContent=text;window.darksecSpeak?.(text);}
  function voiceResults(){if(results.length===1){const place=results[0];applyPlace(place);reply('Seleccioné '+place.name);}else if(results.length){reply('Encontré '+results.length+' lugares. Dime el número del resultado o toca el lugar correcto.');}else reply('No encontré una coincidencia con ese nombre y municipio. Añade el estado o señala el punto en el mapa.');}
  const voiceChoices = document.createElement('div');
  voiceChoices.className = 'map-results';
  status.after(voiceChoices);
  const cleanVoice = text => String(text || '').trim()
    .replace(/^(?:por favor[, ]+)?(?:busca(?:r|me)?|buscar|encuentra|llévame|llevame|quiero ir|muéstrame|muestrame)(?:\s+(?:a|en))?\s+/i, '')
    .replace(/[, ]+por favor[.!]?$/i, '').trim();
  const validPlace = p => p.name && Number.isFinite(p.lat) && Number.isFinite(p.lon) && Math.abs(p.lat)<=90 && Math.abs(p.lon)<=180;
  async function searchPlaces(options={}) {
    const term = query.value.trim();
    if (term.length < 2) { status.textContent = 'Escribe al menos dos caracteres para buscar.'; query.focus(); return; }
    const id = ++searchId;
    activeController?.abort();
    results = []; resultsBox.replaceChildren();
    const coords = term.match(/^(-?\d+(?:\.\d+)?)\s*[,;]\s*(-?\d+(?:\.\d+)?)$/);
    if (coords) {
      const place = {name: term, lat: Number(coords[1]), lon: Number(coords[2])};
      if (!validPlace(place)) { status.textContent='Coordenadas fuera de rango. Usa latitud, longitud.'; return; }
      results=[place]; renderResults(); status.textContent='Elige las coordenadas para mover el mapa.'; return;
    }
    const key=term.toLocaleLowerCase('es');
    if(cache.has(key)){results=cache.get(key);renderResults();status.textContent='Resultados guardados de esta búsqueda.';if(options.voice)voiceResults();return;}
    const delay=Math.max(0,1200-(Date.now()-lastSearch));
    status.textContent='Buscando localidades, playas, ríos y lagunas…';
    await new Promise(resolve=>setTimeout(resolve,delay));
    if(id!==searchId)return;
    lastSearch=Date.now();
    const controller=new AbortController();activeController=controller;
    const timeout=setTimeout(()=>controller.abort(),12000);
    async function json(url){const response=await fetch(url,{signal:controller.signal});if(!response.ok)throw new Error('HTTP '+response.status);return response.json();}
    try {
      const sources=await Promise.allSettled([
        json('https://photon.komoot.io/api/?q='+encodeURIComponent(term)+'&limit=12').then(data=>(data.features||[]).map(f=>{
          const a=f.properties||{}, xy=f.geometry?.coordinates||[];
          return {name:[a.name,a.city,a.district,a.county,a.state,a.country].filter(Boolean).filter((v,i,all)=>all.indexOf(v)===i).join(', '),primaryName:a.name||a.city||a.county||'',lat:Number(xy[1]),lon:Number(xy[0])};
        })),
        json('https://geocoding-api.open-meteo.com/v1/search?name='+encodeURIComponent(term.split(',')[0].trim())+'&count=50&language=es&format=json').then(data=>(data.results||[]).map(r=>({name:cleanPlace(r),primaryName:r.name,lat:Number(r.latitude),lon:Number(r.longitude)})))
      ]);
      if(id!==searchId)return;
      let failed=sources.filter(s=>s.status==='rejected').length;
      const combined=sources.flatMap(s=>s.status==='fulfilled'?s.value:[]).filter(validPlace).filter(p=>!window.DarksecPlaceMatch||window.DarksecPlaceMatch.matches(p,term));
      results=combined.filter((p,i,all)=>!all.slice(0,i).some(q=>Math.abs(p.lat-q.lat)<0.001&&Math.abs(p.lon-q.lon)<0.001)).slice(0,20);
      if(!failed){if(cache.size>=30)cache.delete(cache.keys().next().value);cache.set(key,results);}
      renderResults();
      status.textContent=results.length ? `Elige uno de los ${results.length} lugares encontrados.`+(failed?' Una fuente no respondió; puedes reintentar.':'') : failed ? 'Una fuente no respondió. Comprueba tu conexión y vuelve a buscar.' : 'Sin coincidencias para ese nombre y zona. Añade el estado, usa coordenadas o señala el punto en el mapa.';
      if(options.voice)voiceResults();
    } catch(e) { if(id===searchId)status.textContent='No se pudo completar la búsqueda. Vuelve a intentarlo.'; }
    finally { clearTimeout(timeout); }
  }
  function renderFavorites() {
    const box = byId('favoriteList');
    box.replaceChildren();
    favorites.forEach((place, index) => {
      const chip = document.createElement('div');
      chip.className = 'favorite-chip';
      const use = document.createElement('button');
      use.type = 'button'; use.className = 'favorite-use'; use.textContent = '⭐ ' + place.name;
      use.title = 'Usar ' + place.name + ' para el mapa y el pronóstico';
      use.addEventListener('click', () => applyPlace(place));
      const edit = document.createElement('button');
      edit.type = 'button'; edit.className = 'favorite-edit'; edit.textContent = '✎'; edit.setAttribute('aria-label', 'Cambiar nombre de ' + place.name);
      edit.addEventListener('click', () => {
        const name = prompt('Nombre del lugar favorito:', place.name);
        if (name && name.trim()) { favorites[index] = { ...place, name: name.trim().slice(0, 70) }; persistFavorites(); }
      });
      const del = document.createElement('button');
      del.type = 'button'; del.className = 'favorite-delete'; del.textContent = '×'; del.setAttribute('aria-label', 'Eliminar ' + place.name);
      del.addEventListener('click', () => { favorites.splice(index, 1); persistFavorites(); });
      chip.append(use, edit, del); box.append(chip);
    });
  }
  function saveCurrent() {
    if (!Number.isFinite(window.darksecCurrentLat) || !Number.isFinite(window.darksecCurrentLon)) {
      status.textContent = 'Elige primero una zona en el mapa o usa el GPS.';
      return;
    }
    const suggested = window.darksecPlaceName || '';
    const name = prompt('Pon un nombre para esta zona favorita:', suggested);
    if (!name || !name.trim()) return;
    const place = { name: name.trim().slice(0, 70), lat: Number(window.darksecCurrentLat), lon: Number(window.darksecCurrentLon) };
    const duplicate = favorites.findIndex(p => Math.abs(p.lat - place.lat) < 0.0005 && Math.abs(p.lon - place.lon) < 0.0005);
    if (duplicate >= 0) favorites[duplicate] = place; else favorites.push(place);
    favorites = favorites.filter(p => Number.isFinite(p.lat) && Number.isFinite(p.lon)).slice(-100);
    persistFavorites();
    status.textContent = '⭐ Favorito guardado. Puedes usarlo aquí para actualizar mapa y pronóstico.';
  }
  window.darksecVoiceResult = input => {
    const choices=[...new Set((Array.isArray(input)?input:[input]).filter(t=>typeof t==='string').map(t=>t.trim()).filter(Boolean))].slice(0,5);
    voiceChoices.replaceChildren();
    if(!choices.length){window.darksecVoiceError('No entendí el lugar. Intenta decir nombre, municipio y estado.');return;}
    function execute(text){
      const command=window.DarksecVoiceCommands?.parse(text)||{action:'search',query:cleanVoice(text)};
      if(command.action==='app'){window.darksecCancelSearch();window.darksecAskApp?.(command.query);return;}
      if(command.action==='gps'){++searchId;activeController?.abort();byId('gps')?.click();status.textContent='Solicitando ubicación GPS…';return;}
      if(command.action==='save'){saveCurrent();return;}
      if(command.action==='info'){window.darksecCancelSearch();window.darksecWikiSearch?.(command.query,{speak:true});status.textContent='Buscando una respuesta sobre '+(command.query||'este lugar');return;}
      if(command.action==='read'){window.darksecWikiRead?.();return;}
      if(command.action==='stop'){window.darksecStopSpeaking?.();return;}
      if(command.action==='choose'){const place=results[command.index];if(place){applyPlace(place);reply('Seleccioné '+place.name);}else reply('Ese número no está en los resultados. Primero busca un lugar.');return;}
      if(command.action==='unknown'){reply('Puedo buscar lugares y leer información de Wikipedia. Prueba: qué sabes de la laguna de Tamiahua.');return;}
      query.value=command.query;searchPlaces({voice:true});
    }
    const first=choices[0];
    if(/^(?:usar? (?:el )?gps|mi ubicación(?: actual)?|mi ubicacion(?: actual)?)$/i.test(first)){byId('gps')?.click();status.textContent='Solicitando ubicación GPS…';return;}
    if(choices.length>1){const label=document.createElement('span');label.textContent='¿Dijiste otro lugar?';voiceChoices.append(label);choices.forEach(t=>{const b=document.createElement('button');b.type='button';b.textContent=t;b.onclick=()=>execute(t);voiceChoices.append(b);});}
    execute(first);
  };
  window.darksecVoiceError = message => { status.textContent = message || 'No se pudo iniciar la búsqueda por voz. Puedes escribir el lugar.'; };
  byId('mapSearchSubmit').addEventListener('click', searchPlaces);
  query.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); searchPlaces(); } });
  byId('mapSearchVoice').addEventListener('click', () => {
    window.darksecStopSpeaking?.();
    if (native?.startVoiceSearch) { status.textContent = 'Escuchando… di el nombre de una ciudad o lugar.'; native.startVoiceSearch(); return; }
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) { status.textContent = 'La búsqueda por voz no está disponible aquí. Escribe el lugar en el buscador.'; query.focus(); return; }
    const speech = new Recognition(); speech.lang = 'es-MX'; speech.maxAlternatives=5; speech.onresult = e => window.darksecVoiceResult(Array.from(e.results[0],r=>r.transcript));
    speech.onerror = () => { status.textContent = 'No se reconoció la voz. Escribe el lugar en el buscador.'; };
    try{speech.start();}catch(_){window.darksecVoiceError('No se pudo iniciar el micrófono. Escribe el lugar.');}
  });
  byId('saveFavorite').addEventListener('click', saveCurrent);
  renderFavorites();
  setLabel(window.darksecPlaceName);
})();
