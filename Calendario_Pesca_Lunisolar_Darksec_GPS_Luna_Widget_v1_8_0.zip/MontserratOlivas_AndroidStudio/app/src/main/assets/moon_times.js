/*
 * Cálculo astronómico aproximado del orto y ocaso lunares.
 * Fórmulas estándar de coordenadas lunares, tiempo sideral y refracción atmosférica,
 * descritas en Astronomical Algorithms (Jean Meeus) y SunCalc (V. Agafonkin).
 * Código independiente implementado para Calendario Pesca Lunisolar Darksec.
 * Uso orientativo; relieve, altitud y condiciones locales modifican la hora observada.
 */
(function(){'use strict';
 const rad=Math.PI/180,msDay=86400000;
 function moonAltitude(epoch, lat, lon) {
   const d=epoch/msDay-0.5+2440588-2451545;
   const L=(218.316+13.176396*d)*rad;
   const M=(134.963+13.064993*d)*rad;
   const F=(93.272+13.229350*d)*rad;
   const l=L+6.289*rad*Math.sin(M), b=5.128*rad*Math.sin(F), e=23.4397*rad;
   const ra=Math.atan2(Math.sin(l)*Math.cos(e)-Math.tan(b)*Math.sin(e),Math.cos(l));
   const dec=Math.asin(Math.sin(b)*Math.cos(e)+Math.cos(b)*Math.sin(e)*Math.sin(l));
   const phi=lat*rad, lw=-lon*rad;
   const H=(280.16+360.9856235*d)*rad-lw-ra;
   const h=Math.asin(Math.sin(phi)*Math.sin(dec)+Math.cos(phi)*Math.cos(dec)*Math.cos(H));
   const a=Math.max(0,h);
   const ref=0.0002967/Math.tan(a+0.00312536/(a+0.08901179));
   // Umbral: centro de la Luna en horizonte aparente, con corrección de paralaje/disco.
   return h+ref-0.133*rad;
 }
 function zoneOffsetMillis(epoch, tz) {
   const f=new Intl.DateTimeFormat('en-GB',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
   const p={};f.formatToParts(new Date(epoch)).forEach(x=>{if(x.type!=='literal')p[x.type]=Number(x.value)});
   const represented=Date.UTC(p.year,p.month-1,p.day,p.hour%24,p.minute,p.second);
   return represented-Math.floor(epoch/1000)*1000;
 }
 function midnightUtc(day,tz) {
   const [y,m,d]=day.split('-').map(Number);
   const civil=Date.UTC(y,m-1,d),candidate=new Date(civil);
   if(!Number.isFinite(civil))return null;
   let result=civil;
   // Iteración: ajusta cambios del horario de verano en la zona elegida.
   for(let i=0;i<4;i++)result=civil-zoneOffsetMillis(result,tz);
   return result;
 }
 function findTimes(day,lat,lon,tz) {
   if(!/^\d{4}-\d\d-\d\d$/.test(day)||!Number.isFinite(lat)||Math.abs(lat)>90||!Number.isFinite(lon)||Math.abs(lon)>180)return null;
   let start,end;
   try{
     start=midnightUtc(day,tz);
     const [y,m,d]=day.split('-').map(Number);
     const following=new Date(Date.UTC(y,m-1,d+1)).toISOString().slice(0,10);
     end=midnightUtc(following,tz);
   }catch(e){return null}
   if(start==null||end==null||end<=start||end-start>26*3600000)return null;
   const points=[],step=10*60000;
   let a=start,ha=moonAltitude(a,lat,lon),allUp=ha>0,allDown=ha<0;
   for(let b=Math.min(end,a+step);a<end;b=Math.min(end,a+step)){
     const hb=moonAltitude(b,lat,lon);
     allUp=allUp&&hb>0;allDown=allDown&&hb<0;
     if((ha<=0&&hb>0)||(ha>=0&&hb<0)){
       const rising=ha<=0&&hb>0;
       let lo=a,hi=b;
       for(let i=0;i<18;i++){
         const mid=(lo+hi)/2,hm=moonAltitude(mid,lat,lon);
         if((hm>0)===rising)hi=mid;else lo=mid;
       }
       points.push({type:rising?'rise':'set',at:new Date((lo+hi)/2)});
     }
     a=b;ha=hb;
   }
   const rise=points.filter(x=>x.type==='rise').map(x=>x.at);
   const set=points.filter(x=>x.type==='set').map(x=>x.at);
   return {rise,set,alwaysUp:allUp,alwaysDown:allDown,timeZone:tz};
 }
 window.DarksecMoon={findTimes,moonAltitude,midnightUtc};
})();
