package com.montserratolivas.pesca;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;

/** Estado compacto del pronóstico, disponible para el widget sin conexión ni ejecutar WebView. */
public final class WeatherWidgetStore {
    private WeatherWidgetStore() { }
    private static String value(JSONObject j, String key, String fallback, int length) {
        String text = j.optString(key, fallback);
        if (text == null || text.trim().isEmpty() || text.length() > length) return fallback;
        return text;
    }
    public static void save(Context c, String raw) {
        try {
            JSONObject j = new JSONObject(raw);
            long timestamp = j.optLong("updatedAt", 0L);
            long now = System.currentTimeMillis();
            if (timestamp <= 0 || timestamp > now + 60000L || now - timestamp > 24L * 3600000L) return;
            SharedPreferences prefs = AppSettings.prefs(c);
            if (timestamp < prefs.getLong("widget_weather_updated", 0L)) return;
            String level = j.optString("risk", "unknown");
            if (!level.equals("good") && !level.equals("caution") && !level.equals("bad")) level = "unknown";
            prefs.edit()
                .putLong("widget_weather_updated", timestamp)
                .putString("widget_status", value(j, "status", "Sin pronóstico", 32))
                .putString("widget_risk_level", level)
                .putString("widget_risk_detail", value(j, "riskDetail", "", 80))
                .putString("widget_risk_time", value(j, "riskTime", "", 5))
                .putString("widget_temp", value(j, "temp", "— °C", 20))
                .putString("widget_rain", value(j, "rain", "— %", 20))
                .putString("widget_wind", value(j, "wind", "— km/h", 20))
                .putString("widget_zone", value(j, "zone", "Ubicación elegida", 38))
                .putString("widget_forecast_time", value(j, "forecastTime", "", 24))
                .apply();
            MoonWidget.refresh(c);
        } catch (Exception ignored) { }
    }
}
