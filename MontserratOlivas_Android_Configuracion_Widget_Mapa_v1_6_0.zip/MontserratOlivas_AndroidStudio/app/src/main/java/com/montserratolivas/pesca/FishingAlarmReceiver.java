package com.montserratolivas.pesca;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Locale;

public class FishingAlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL = "pesca_horas";
    public static final String WEATHER_CHANNEL = "pesca_clima";
    public static void channel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationChannel fishing = new NotificationChannel(CHANNEL, "Mejores horas para pescar", NotificationManager.IMPORTANCE_DEFAULT);
            fishing.setDescription("Recordatorios de horas con índice de pesca favorable");
            nm.createNotificationChannel(fishing);
            NotificationChannel weather = new NotificationChannel(WEATHER_CHANNEL, "Alertas del pronóstico del clima", NotificationManager.IMPORTANCE_HIGH);
            weather.setDescription("Riesgos estimados del pronóstico, no alertas oficiales de Protección Civil");
            nm.createNotificationChannel(weather);
        }
    }
    public static String displayHour(Context c, String hhmm) {
        if (hhmm == null || hhmm.length() < 5 || !"12h".equals(AppSettings.prefs(c).getString("time_format", "24h"))) return hhmm;
        try {
            int hour = Integer.parseInt(hhmm.substring(0,2));
            int minutes = Integer.parseInt(hhmm.substring(3,5));
            return String.format(Locale.getDefault(), "%d:%02d %s", ((hour + 11) % 12) + 1, minutes, hour >= 12 ? "PM" : "AM");
        } catch(Exception ignored) { return hhmm; }
    }
    @Override public void onReceive(Context c, Intent intent) {
        if (!AppSettings.prefs(c).getBoolean("alerts_enabled", true)) return;
        channel(c);
        String hour = intent.getStringExtra("hour");
        String day = intent.getStringExtra("day");
        int lead = intent.getIntExtra("leadHours", 1);
        int score = intent.getIntExtra("score", 0);
        Intent launch = new Intent(c, MainActivity.class);
        PendingIntent open = PendingIntent.getActivity(c, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
        String advance = lead < 24 ? lead + " h" : (lead % 24 == 0 ? lead / 24 + " día(s)" : lead + " h");
        b.setSmallIcon(android.R.drawable.ic_menu_my_calendar)
            .setContentTitle("🎣 Hora favorable en " + advance)
            .setContentText(day + " " + displayHour(c, hour) + " · Índice " + score + "/100. Revisa el clima actualizado.")
            .setAutoCancel(true).setContentIntent(open);
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(intent.getIntExtra("id", 700), b.build());
        } catch (SecurityException ignored) { }
    }
    public static void sendWeather(Context c, String title, String message, int id) {
        channel(c);
        Intent launch = new Intent(c, MainActivity.class);
        PendingIntent open = PendingIntent.getActivity(c, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, WEATHER_CHANNEL) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title).setContentText(message)
            .setStyle(new Notification.BigTextStyle().bigText(message))
            .setAutoCancel(true).setContentIntent(open);
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(id, b.build());
        } catch (SecurityException ignored) { }
    }
}
