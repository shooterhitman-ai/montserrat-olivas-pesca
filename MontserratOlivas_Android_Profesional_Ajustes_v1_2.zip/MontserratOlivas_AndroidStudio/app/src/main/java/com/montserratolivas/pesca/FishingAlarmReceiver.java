package com.montserratolivas.pesca;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class FishingAlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL = "pesca_horas";
    public static void channel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Mejores horas para pescar", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Recordatorios de periodos favorables de pesca");
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }
    @Override public void onReceive(Context c, Intent intent) {
        if (!AppSettings.prefs(c).getBoolean("alerts_enabled", true)) return;
        channel(c);
        String hour = intent.getStringExtra("hour");
        if (hour == null) hour = "próximamente";
        int lead = intent.getIntExtra("lead", 60);
        Intent launch = new Intent(c, MainActivity.class);
        PendingIntent open = PendingIntent.getActivity(c, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_menu_my_calendar)
            .setContentTitle("🎣 Buena hora para pescar en " + lead + " min")
            .setContentText("Periodo estimado: " + hour + ". Consulta el clima antes de salir.")
            .setAutoCancel(true).setContentIntent(open);
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(intent.getIntExtra("id", 700), b.build());
        } catch (SecurityException ignored) { }
    }
}
