package com.montserratolivas.pesca;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Agenda alertas basadas en el último pronóstico consultado por el usuario. */
public final class FishingScheduler {
    private FishingScheduler() { }
    static void cancel(Context c) {
        AlarmManager manager = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        for (int i = 0; i < 3; i++) {
            PendingIntent pi = PendingIntent.getBroadcast(c, 700 + i,
                new Intent(c, FishingAlarmReceiver.class), PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) { manager.cancel(pi); pi.cancel(); }
        }
    }
    static String join(JSONArray times) throws Exception {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < Math.min(3, times.length()); i++) {
            if (i > 0) out.append(" · ");
            out.append(times.getString(i));
        }
        return out.toString();
    }
    public static void apply(Context c, String json, boolean save) {
        try {
            JSONObject schedule = new JSONObject(json);
            String day = schedule.getString("day");
            JSONArray hours = schedule.getJSONArray("hours");
            SharedPreferences p = AppSettings.prefs(c);
            if (save) p.edit().putString("schedule", json).putString("day", day).putString("hours", join(hours)).apply();
            cancel(c);
            if (!p.getBoolean("alerts_enabled", true)) { MoonWidget.refresh(c); return; }
            AlarmManager manager = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (manager == null) return;
            int lead = p.getInt("lead_minutes", 60);
            int max = Math.max(1, Math.min(3, p.getInt("max_alerts", 3)));
            JSONArray instants = schedule.optJSONArray("epochMs");
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
            fmt.setLenient(false);
            int scheduled = 0;
            for (int i = 0; i < hours.length() && scheduled < max; i++) {
                String hour = hours.getString(i);
                // epochMs tiene en cuenta la zona horaria del lugar del pronóstico.
                long start = instants != null && i < instants.length() ? instants.getLong(i)
                    : fmt.parse(day + " " + hour).getTime();
                long at = start - lead * 60000L;
                if (at <= System.currentTimeMillis()) continue;
                Intent intent = new Intent(c, FishingAlarmReceiver.class)
                    .putExtra("hour", hour).putExtra("lead", lead).putExtra("id", 700 + scheduled);
                PendingIntent pi = PendingIntent.getBroadcast(c, 700 + scheduled, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                scheduled++;
            }
            MoonWidget.refresh(c);
        } catch (Exception ignored) { }
    }
    public static void restore(Context c) {
        String saved = AppSettings.prefs(c).getString("schedule", null);
        if (saved != null) apply(c, saved, false);
        else { cancel(c); MoonWidget.refresh(c); }
    }
}
