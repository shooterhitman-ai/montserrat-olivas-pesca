package com.montserratolivas.pesca;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;

/** Preferencias compartidas entre la pantalla, los avisos y el widget. */
public final class AppSettings {
    private AppSettings() { }
    public static SharedPreferences prefs(Context c) { return c.getSharedPreferences("pesca", Context.MODE_PRIVATE); }

    public static JSONObject read(Context c) {
        SharedPreferences p = prefs(c);
        JSONObject j = new JSONObject();
        try {
            j.put("alertsEnabled", p.getBoolean("alerts_enabled", true));
            j.put("leadMinutes", p.getInt("lead_minutes", 60));
            j.put("maxAlerts", p.getInt("max_alerts", 3));
            j.put("widgetHours", p.getBoolean("widget_hours", true));
            j.put("widgetTheme", p.getString("widget_theme", "ocean"));
            j.put("showBackground", p.getBoolean("show_background", true));
            j.put("compactView", p.getBoolean("compact_view", false));
            j.put("theme", p.getString("theme", "ocean"));
            j.put("windUnit", p.getString("wind_unit", "kmh"));
            j.put("fishingMode", p.getString("fishing_mode", "coast"));
        } catch (Exception ignored) { }
        return j;
    }

    public static void save(Context c, String json) {
        try {
            JSONObject j = new JSONObject(json);
            SharedPreferences.Editor e = prefs(c).edit();
            e.putBoolean("alerts_enabled", j.optBoolean("alertsEnabled", true));
            int minutes = j.optInt("leadMinutes", 60);
            e.putInt("lead_minutes", minutes == 15 || minutes == 30 || minutes == 60 || minutes == 120 ? minutes : 60);
            e.putInt("max_alerts", Math.max(1, Math.min(3, j.optInt("maxAlerts", 3))));
            e.putBoolean("widget_hours", j.optBoolean("widgetHours", true));
            String widgetTheme = j.optString("widgetTheme", "ocean");
            e.putString("widget_theme", widgetTheme.equals("night") || widgetTheme.equals("forest") ? widgetTheme : "ocean");
            e.putBoolean("show_background", j.optBoolean("showBackground", true));
            e.putBoolean("compact_view", j.optBoolean("compactView", false));
            String theme = j.optString("theme", "ocean");
            e.putString("theme", theme.equals("night") || theme.equals("forest") ? theme : "ocean");
            e.putString("wind_unit", j.optString("windUnit", "kmh").equals("knots") ? "knots" : "kmh");
            e.putString("fishing_mode", j.optString("fishingMode", "coast").equals("inland") ? "inland" : "coast");
            e.apply();
            FishingScheduler.restore(c);
            MoonWidget.refresh(c);
        } catch (Exception ignored) { }
    }
}
