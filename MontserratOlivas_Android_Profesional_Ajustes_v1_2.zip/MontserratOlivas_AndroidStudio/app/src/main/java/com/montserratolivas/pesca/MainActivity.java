package com.montserratolivas.pesca;

import android.Manifest;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int LOCATION_REQUEST = 101;
    private static final int NOTIFICATION_REQUEST = 102;
    private volatile boolean settingsOpen = false;
    private GeolocationPermissions.Callback pendingCallback;
    private String pendingOrigin;

    public class NativeBridge {
        @JavascriptInterface public void settingsVisibility(boolean visible) { settingsOpen = visible; }
        @JavascriptInterface public String getSettings() { return AppSettings.read(MainActivity.this).toString(); }
        @JavascriptInterface public void saveSettings(String json) {
            runOnUiThread(() -> AppSettings.save(MainActivity.this, json));
        }
        @JavascriptInterface public void updateFishingTimes(String json) {
            runOnUiThread(() -> FishingScheduler.apply(MainActivity.this, json, true));
        }
        @JavascriptInterface public boolean notificationPermissionGranted() {
            return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }
        @JavascriptInterface public void requestNotificationPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
                }
            });
        }
        @JavascriptInterface public void openNotificationSettings() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                    i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                    startActivity(i);
                } catch (Exception e) {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                }
            });
        }
        @JavascriptInterface public boolean canPinWidget() {
            return Build.VERSION.SDK_INT >= 26 && AppWidgetManager.getInstance(MainActivity.this).isRequestPinAppWidgetSupported();
        }
        @JavascriptInterface public void pinMoonWidget() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 26) {
                    AppWidgetManager manager = AppWidgetManager.getInstance(MainActivity.this);
                    if (manager.isRequestPinAppWidgetSupported()) {
                        manager.requestPinAppWidget(new ComponentName(MainActivity.this, MoonWidget.class), null, null);
                    }
                }
            });
        }
        @JavascriptInterface public int widgetCount() {
            int[] ids = AppWidgetManager.getInstance(MainActivity.this)
                .getAppWidgetIds(new ComponentName(MainActivity.this, MoonWidget.class));
            return ids == null ? 0 : ids.length;
        }
        @JavascriptInterface public void refreshWidget() {
            runOnUiThread(() -> MoonWidget.refresh(MainActivity.this));
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8, 22, 33));
        getWindow().setNavigationBarColor(Color.rgb(8, 22, 33));
        FishingAlarmReceiver.channel(this);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setGeolocationEnabled(true);
        webView.addJavascriptInterface(new NativeBridge(), "PescaAndroid");
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri address = request.getUrl();
                if ("appassets.androidplatform.net".equals(address.getHost())) return false;
                // Los enlaces externos se abren fuera de la aplicación; el puente nativo queda aislado.
                try { startActivity(new Intent(Intent.ACTION_VIEW, address)); }
                catch (Exception ignored) { }
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingCallback = callback;
                    pendingOrigin = origin;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
                }
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        MoonWidget.refresh(this);
    }
    @Override protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.evaluateJavascript("window.updatePermissionLabel && window.updatePermissionLabel(); window.updateWidgetStatus && window.updateWidgetStatus();", null);
        }
    }
    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == LOCATION_REQUEST && pendingCallback != null) {
            boolean ok = false;
            for (int grant : results) if (grant == PackageManager.PERMISSION_GRANTED) ok = true;
            pendingCallback.invoke(pendingOrigin, ok, false);
            pendingCallback = null;
            pendingOrigin = null;
        }
        if (code == NOTIFICATION_REQUEST && webView != null) {
            webView.evaluateJavascript("window.updatePermissionLabel && window.updatePermissionLabel()", null);
        }
    }
    @Override public void onBackPressed() {
        if (settingsOpen && webView != null) {
            webView.evaluateJavascript("window.closeSettingsIfOpen && window.closeSettingsIfOpen()", null);
            return;
        }
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
