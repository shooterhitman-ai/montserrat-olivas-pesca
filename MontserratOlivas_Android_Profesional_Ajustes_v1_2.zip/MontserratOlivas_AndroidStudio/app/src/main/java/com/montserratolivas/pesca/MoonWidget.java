package com.montserratolivas.pesca;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.RemoteViews;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MoonWidget extends AppWidgetProvider {
    public static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, MoonWidget.class));
        if (ids != null && ids.length > 0) new MoonWidget().onUpdate(c, m, ids);
    }
    @Override public void onUpdate(Context c, AppWidgetManager manager, int[] ids) {
        SharedPreferences prefs = AppSettings.prefs(c);
        double days = (System.currentTimeMillis() / 86400000.0 - 10957.5 - 5.2597) % 29.530588853;
        if (days < 0) days += 29.530588853;
        String[] names = {"Nueva", "Creciente", "Cuarto creciente", "Gibosa creciente", "Llena", "Gibosa menguante", "Cuarto menguante", "Menguante"};
        String[] emojis = {"🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘"};
        int phase = ((int) Math.round(days / 29.530588853 * 8)) % 8;
        String date = prefs.getString("day", "");
        String hours = prefs.getString("hours", "");
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        boolean showHours = prefs.getBoolean("widget_hours", true);
        for (int id : ids) {
            RemoteViews view = new RemoteViews(c.getPackageName(), R.layout.moon_widget);
            String theme = prefs.getString("widget_theme", "ocean");
            int background = theme.equals("forest") ? R.drawable.widget_background_forest
                : theme.equals("night") ? R.drawable.widget_background_night : R.drawable.widget_background;
            view.setInt(R.id.widget_root, "setBackgroundResource", background);
            view.setTextViewText(R.id.widget_moon, emojis[phase] + "  Luna " + names[phase]);
            view.setTextViewText(R.id.widget_subtitle, "Fase lunar aproximada · hoy");
            view.setViewVisibility(R.id.widget_hours, showHours ? View.VISIBLE : View.GONE);
            view.setTextViewText(R.id.widget_hours, date.equals(today) && !hours.isEmpty()
                ? "🎣 Horas favorables: " + hours
                : "Abre la app para actualizar las horas");
            Intent open = new Intent(c, MainActivity.class);
            PendingIntent action = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            view.setOnClickPendingIntent(R.id.widget_root, action);
            manager.updateAppWidget(id, view);
        }
    }
}
